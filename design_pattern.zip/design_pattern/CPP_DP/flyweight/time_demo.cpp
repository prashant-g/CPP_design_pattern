#include<iostream>

using namespace std;

class Time
{
	int min;
	int hr;
	int sec;
public:
	Time(int h,int m,int s)
	{
		min=m;
		hr=h;
		sec=s;
	}
	void showTime()
	{
		cout<<hr<<"::"<<min<<"::"<<sec<<endl;
	}
	int gethr()
	{
		return hr;
	}
friend ostream & operator <<(ostream &os, Time &t);
};


ostream & operator <<(ostream &os, Time &t)
{
	os<<t.hr<<"::"<<t.min<<"::"<<t.sec<<endl;
	return os;
}


int main()
{
	Time t1(11,19,45);
	Time t2(12,22,45);
	cout<<t1<<t2<<endl;// <<(os,endl)

}

