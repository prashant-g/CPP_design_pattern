#include <iostream>
#include <unordered_map>
#include <string>
using namespace std;

// Flyweight
class FontStyle {

public:
    string font;
    int size;
    string color;
    FontStyle(const string& f, int s, const string& c) : font(f), size(s), color(c) {}
    
    virtual void apply() const = 0;
};
class FontStyleConcrete : public FontStyle{
	public:
    FontStyleConcrete(const string& f, int s, const string& c) : FontStyle(f,s,c) {}

    void apply() const {
        cout << "Applying style: " << font << ", size " << size << ", color " << color << endl;
    }
};

// Flyweight Factory
class StyleFactory {
    unordered_map<string, FontStyle*> styles;

public:
    FontStyle* getStyle(const string& font, int size, const string& color) {
        string key = font + to_string(size) + color;
        
        if (styles.find(key) == styles.end()) {
            styles[key] = new FontStyleConcrete(font, size, color);
        }
        return styles[key];
    }

    ~StyleFactory() {
        for (auto& pair : styles) {
            delete pair.second;
        }
    }
};


class Character {
    char symbol;
    FontStyle* style;

public:
    Character(char s, FontStyle* st) : symbol(s), style(st) {}

    void display() const {
        cout << "Character: " << symbol << " with ";
        style->apply();
    }
};

// Client code
int main() {
    StyleFactory factory;

    Character text[] = {
        Character('H', factory.getStyle("Arial", 12, "Black")),
        Character('e', factory.getStyle("Arial", 12, "Black")),
        Character('l', factory.getStyle("Arial", 12, "Black")),
        Character('l', factory.getStyle("Arial", 12, "Black")),
        Character('o', factory.getStyle("Arial", 12, "Black")),
        Character('W', factory.getStyle("Arial", 14, "Red")),
        Character('o', factory.getStyle("Arial", 14, "Red")),
        Character('r', factory.getStyle("Arial", 14, "Red")),
        Character('l', factory.getStyle("Arial", 14, "Red")),
        Character('d', factory.getStyle("Arial", 14, "Red"))
    };

    for (const auto& ch : text) {
        ch.display();
    }

    return 0;
}
