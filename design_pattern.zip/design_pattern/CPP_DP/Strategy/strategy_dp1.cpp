#include<iostream>
#include<string>
#include<list>
#include<algorithm>
using namespace std;

class PaymentStrategy {

	public :
		virtual void pay(int amount)=0;
};


class CreditCardStrategy : public PaymentStrategy {

	private:
	       	string name;
		string cardNumber;
		string cvv;
		string dateOfExpiry;

	public :
		CreditCardStrategy(string nm, string ccNum, string cvv, string expiryDate){
		this->name=nm;
		this->cardNumber=ccNum;
		this->cvv=cvv;
		this->dateOfExpiry=expiryDate;
	}
	void pay(int amount) {
		cout<<amount <<" paid with credit/debit card"<<endl;
	}

};

class PaypalStrategy : public PaymentStrategy {

	private:
		string emailId;
		string password;

	public :
		PaypalStrategy(string email, string pwd){
		this->emailId=email;
		this->password=pwd;
	}

	void pay(int amount) {
		cout<<amount << " paid using Paypal."<<endl;
	}

};

class Item {

	private :
		string upcCode;
		int price;

	public :
		Item(string upc, int cost){
		this->upcCode=upc;
		this->price=cost;
	}

		string getUpcCode() {
		return upcCode;
	}
		int getPrice() {
		return price;
	}

};


class ShoppingCart {

	//List of items
	list<Item *> items;

	public :
	ShoppingCart(){
	}

	void addItem(Item *item){
		items.push_back(item);
	}

	void removeItem(Item *item){
		items.erase(find(items.begin(),items.end(),item));
	}

	int calculateTotal(){
		int sum = 0;
		for(Item *item : items){
			sum += item->getPrice();
		}
		return sum;
	}

	void pay(PaymentStrategy *paymentMethod){
		int amount = calculateTotal();
		paymentMethod->pay(amount);
	}
};

int main() 
{
		ShoppingCart *cart = new ShoppingCart;

		Item *item1 = new Item("1234",10);
		Item *item2 = new Item("5678",40);

		cart->addItem(item1);
		cart->addItem(item2);

		//pay by paypal
		cart->pay(new PaypalStrategy("myemail@example.com", "mypwd"));

		//pay by credit card
		cart->pay(new CreditCardStrategy("Rahul Dravid", "1234123412341234", "394", "12/29"));

}
