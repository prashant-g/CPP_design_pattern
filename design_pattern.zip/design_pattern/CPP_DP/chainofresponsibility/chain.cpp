#include<iostream>
#include<string>
using namespace std;
		static int OUTPUTINFO=1;
		static int ERRORINFO=2;
		static int DEBUGINFO=3;
class Logger {
	
	protected :
		int levels;
		Logger *nextLevelLogger;
	public:
		virtual void displayLogInfo(string &msg)=0;
		void setNextLevelLogger(Logger *nextLevelLogger) {
		this->nextLevelLogger = nextLevelLogger;
	}
	
	
	void logMessage(int levels, string msg){
		
		if(this->levels<=levels){
			displayLogInfo(msg);
		}
		
		
		if (nextLevelLogger!=NULL) {
			
			nextLevelLogger->logMessage(levels, msg);
		}          
	}
};

class ConsoleBasedLogger : public Logger {
	
	
	public :
		ConsoleBasedLogger(int levels) {
		this->levels=levels;
	}
	void displayLogInfo(string &msg) {
		
		cout<<"CONSOLE LOGGER INFO: "<<msg<<endl;
	}
};

class DebugBasedLogger : public Logger {
	public :
		DebugBasedLogger(int levels) {
		this->levels=levels;
	}
	void displayLogInfo(string &msg) {
		cout<<"DEBUG LOGGER INFO: "<<msg<<endl;
	}
};
class ErrorBasedLogger : public Logger {
	public:
	       	ErrorBasedLogger(int levels) {
		this->levels=levels;
	}
	void displayLogInfo(string &msg) {
		cout<<"ERROR LOGGER INFO: "<<msg<<endl;
	}
};

	Logger * doChaining(){
		
	      Logger *consoleLogger = new ConsoleBasedLogger(OUTPUTINFO);
	      
	      Logger *errorLogger = new ErrorBasedLogger(ERRORINFO);
	      consoleLogger->setNextLevelLogger(errorLogger);
	      
	      Logger *debugLogger = new DebugBasedLogger(DEBUGINFO);
	      errorLogger->setNextLevelLogger(debugLogger);
	      
	      return consoleLogger;
	}

int main()
{
	Logger *chainLogger= doChaining();
	chainLogger->logMessage(OUTPUTINFO, "Enter the sequence of values ");
	cout<<"*****************************************************************"<<endl;
	chainLogger->logMessage(ERRORINFO, "An error is occured now");
	cout<<"*****************************************************************"<<endl;
	chainLogger->logMessage(DEBUGINFO, "This was the error now debugging is compeled");
}
