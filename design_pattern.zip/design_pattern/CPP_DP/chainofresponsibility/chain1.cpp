/*Chain of Responsibility is a behavioral design pattern that lets you pass requests along a chain of handlers. Upon receiving a request, each handler decides either to process the request or to pass it to the next handler in the chain.*/

#include<iostream>
#include<vector>
#include<string>
using namespace std;
class PurhcaseRequest {
private:
    int amount;
    bool approved_status{false};
    string approved_by;
public:
    PurhcaseRequest(const int n) : amount{n} {} 

    int GetAmount() const {return amount;}

    void ProcessPR(const string& approver) {
        approved_by = approver;
        approved_status = true;
    }
    void GetStatus() {
        std::cout << "---- Purchase Order Summary ----" << std::endl;
        std::cout << "Amount: " << amount << std::endl;
        std::cout << "Approved Status: " <<  approved_status << std::endl;
        std::cout << "Approver Name: " << approved_by << std::endl;
        std::cout << "--------------------------------" << std::endl;
    }

};

class Handler{
public:
    virtual Handler* SetNext(Handler* next) = 0;
    virtual void Handle(PurhcaseRequest& request) = 0;
};

class Employee : public Handler {
public:
    Employee() : next{nullptr} {}
    Handler* SetNext(Handler* next) override{
        this->next = next;
        return next;
    }

    void Handle(PurhcaseRequest& request) override {
        if (this->next != nullptr) {
            this->next->Handle(request);
        }
    }

    void Approve(PurhcaseRequest& request) {
        request.ProcessPR(name);
    }

private:
    Handler* next;

protected:
    int approval_limit;
    string name;

    Employee(const string& name, const int& limit) :name{name}, approval_limit{limit}, next{nullptr} {}
};


class JuniorAssociate : public Employee {
public:
    JuniorAssociate() : Employee("Junior",500)
	{}
    

    void Handle(PurhcaseRequest& request) override {
        std::cout << name << "[ ";
        if(request.GetAmount() <= approval_limit) {
            std::cout << "O ] ";
            Approve(request);
        } else {
            std::cout << "X ] ";
            Employee::Handle(request);
        }
    }
};

class SeniorAssociate : public Employee{
public:
    SeniorAssociate() : Employee("Senior", 1500) {}

    void Handle(PurhcaseRequest& request) override {
        std::cout << name << "[ ";
        if(request.GetAmount() <= approval_limit) {
            std::cout << "O ] ";
            Approve(request);
        } else {
            std::cout << "X ] ";
            Employee::Handle(request);
        }
    }
};

class Manager : public Employee {
public:
    Manager() : Employee("Manager", 3000) {}

    void Handle(PurhcaseRequest& request) override {
        std::cout << name << "[ ";
        if(request.GetAmount() <= approval_limit) {
            std::cout << "O ] ";
            Approve(request);
        } else {
            std::cout << "X ] ";
            Employee::Handle(request);
        }
    }
};


void ApprovalWorkflow(Handler* handler_ptr) {
    handler_ptr->SetNext(new SeniorAssociate())->SetNext(new Manager());

   vector<PurhcaseRequest> PRs{PurhcaseRequest(200),PurhcaseRequest(600),PurhcaseRequest(1600),PurhcaseRequest(5000)};

    for(auto& PR : PRs) {
        cout << "\n";
        cout << "Approval Flow: ";
        handler_ptr->Handle(PR);
        std::cout << "\n\n";
        PR.GetStatus();
    }
}




int main() {

    Handler* junior_ptr = new JuniorAssociate();
    ApprovalWorkflow(junior_ptr);


    return 0;
}


