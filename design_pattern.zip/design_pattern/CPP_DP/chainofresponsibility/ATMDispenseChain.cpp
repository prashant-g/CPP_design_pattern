#include<iostream>
using namespace std;
class Currency {

	private :
	int amount;
	
	public :
	Currency(int amt){
		this->amount=amt;
	}
	
	int getAmount(){
		return this->amount;
	}
};

class DispenseChain 
{
public :
virtual void setNextChain(DispenseChain *)=0;
virtual void dispense(Currency *)=0;
};


class Dollar10Dispenser : public DispenseChain {

	private :
	DispenseChain *chain;
	
	public :
	void setNextChain(DispenseChain *nextChain) {
		this->chain=nextChain;
	}

	
	 void dispense(Currency *cur) {
		if(cur->getAmount() >= 10){
			int num = cur->getAmount()/10;
			int remainder = cur->getAmount() % 10;
			cout<<"Dispensing "<<num<<" 10$ note"<<endl;
		}
	}

};


class Dollar20Dispenser :public DispenseChain{

	private:
	 DispenseChain *chain;
	
	
	public :
	void setNextChain(DispenseChain *nextChain) {
		this->chain=nextChain;
	}

	 void dispense(Currency *cur) {
		if(cur->getAmount() >= 20){
			int num = cur->getAmount()/20;
			int remainder = cur->getAmount() % 20;
			cout<<"Dispensing "<<num<<" 20$ note"<<endl;
			if(remainder !=0) this->chain->dispense(new Currency(remainder));
		}else{
			this->chain->dispense(cur);
		}
	}

};


class Dollar50Dispenser : public DispenseChain{

	private:
	 DispenseChain *chain;
	
	
	public :
	void setNextChain(DispenseChain *nextChain) {
		this->chain=nextChain;
	}

	 void dispense(Currency *cur) {
		if(cur->getAmount() >= 50){
			int num = cur->getAmount()/50;
			int remainder = cur->getAmount() % 50;
			cout<<"Dispensing "<<num<<" 50$ note"<<endl;
			if(remainder !=0) this->chain->dispense(new Currency(remainder));
		}else{
			this->chain->dispense(cur);
		}
	}

};


class ATMDispenseChain {

	public :
	DispenseChain *c1;

	 ATMDispenseChain() {
		// initialize the chain
		this->c1 = new Dollar50Dispenser;
		DispenseChain *c2 = new Dollar20Dispenser;
		DispenseChain *c3 = new Dollar10Dispenser;

		// set the chain of responsibility
		c1->setNextChain(c2);
		c2->setNextChain(c3);
	}
};

int main() {
		ATMDispenseChain *atmDispenser = new ATMDispenseChain();
		while (true) {
			int amount = 0;
			cout<<"Enter amount to dispense :: ";
			cin>>amount; //180
			
			if (amount % 10 != 0) {
				cout<<"Amount should be in multiple of 10s."<<endl;
				return 0;
			}
			// process the request
			atmDispenser->c1->dispense(new Currency(amount));
		}

}

