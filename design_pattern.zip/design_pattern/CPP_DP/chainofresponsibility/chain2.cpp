#include <string>
#include <iostream>

using namespace std;

struct Event {
  int id = -1;
  std::string message = "";
};

class IHandler {
public:
  virtual ~IHandler() {}
  virtual IHandler* SetNext(IHandler* handler) = 0;
  virtual Event Handle(Event event) = 0;
};

class BaseHandler : public IHandler {
private:
  IHandler* next_handler;
public:
  BaseHandler() : next_handler(nullptr) {}

  IHandler* SetNext(IHandler* handler) override {
    next_handler = handler;
    return handler;
  }

  Event Handle(Event event) override {
    if (next_handler) {
      return next_handler->Handle(event);
    }

    return event;
  }
};

class HandleEvent1 : public BaseHandler {
public:
  Event Handle(Event event) override {
    if (event.id == 1) {
      std::cout << "-> handling event with id 1\n";
      std::cout << "   event message: " << event.message << std::endl;
      return event;
    }
    return BaseHandler::Handle(event);
  }
};

class HandleEvent2 : public BaseHandler {
public:
  Event Handle(Event event) override {
    if (event.id == 2) {
      std::cout << "-> handling event with id 2\n";
      std::cout << "   event message: " << event.message << std::endl;
      return event;
    }
    return BaseHandler::Handle(event);
  }
};

class HandleEvent3 : public BaseHandler {
public:
  Event Handle(Event event) override {
    if (event.id == 3) {
      std::cout << "-> handling event with id 3\n";
      std::cout << "   event message: " << event.message << std::endl;
      return event;
    }
    return BaseHandler::Handle(event);
  }
};



int main() {
  HandleEvent1* handleevent1 = new HandleEvent1;
  HandleEvent2* handleevent2 = new HandleEvent2;
  HandleEvent3* handleevent3 = new HandleEvent3;
  handleevent1->SetNext(handleevent2)->SetNext(handleevent3);

  {
    std::cout << "TEST1\n";
    Event an_event;
    an_event.id = 1;
    an_event.message = "why hello there from TEST1";
    Event returned_event = handleevent1->Handle(an_event);
    std::cout << "returned event id: " << returned_event.id << std::endl;
  }

  {
    std::cout << "TEST2\n";
    Event an_event;
    an_event.id = 2;
    an_event.message = "why hello there from TEST2";
    Event returned_event = handleevent1->Handle(an_event);
    std::cout << "returned event id: " << returned_event.id << std::endl;
  }

  {
    std::cout << "TEST3\n";
    Event an_event;
    an_event.id = 3;
    an_event.message = "why hello there from TEST3";
    Event returned_event = handleevent1->Handle(an_event);
    std::cout << "returned event id: " << returned_event.id << std::endl;
  }


  {
    std::cout << "TEST4\n";
    Event an_event;
    an_event.id = 4;
    an_event.message = "why hello there from TEST4";
    Event returned_event = handleevent1->Handle(an_event);
    std::cout << "returned event id: " << returned_event.id << std::endl;
  }

}
