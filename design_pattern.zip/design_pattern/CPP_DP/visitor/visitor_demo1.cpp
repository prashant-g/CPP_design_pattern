#include <iostream>
using namespace std;
class Watch;
class DVD;
class Sunglasses;
class Visitor
{
public:

    virtual ~Visitor() {}

    virtual double visit(Sunglasses* sunglasses) = 0;
    virtual double visit(DVD* dvd) = 0;
    virtual double visit(Watch* watch) = 0;
};
class Product
{
public:
    virtual ~Product() {}
	Product(){}


    virtual double accept(Visitor* visitor) = 0;
    virtual double getPrice() = 0;
};

class Watch : public Product
{
public:
    Watch(double initialPrice):price_(initialPrice)
{
}

~Watch()
{
}

double accept(Visitor* visitor)
{
    return visitor->visit(this);
}

double getPrice()
{
    return price_;
}
private:
    double price_;
};


class Sunglasses : public Product
{
public:
   Sunglasses(double initialPrice):price_(initialPrice)
{
}

~Sunglasses()
{
}

double accept(Visitor* visitor)
{
    return visitor->visit(this);
}

double getPrice()
{
    return price_;
}


private:
    double price_;
};


class DVD : public Product
{
public:
    DVD(double initialPrice):price_(initialPrice)
{
}

~DVD()
{
}

double accept(Visitor* visitor)
{
    return visitor->visit(this);
}

double getPrice()
{
    return price_;
}

private:
    double price_;
};



class CustomsVisitor : public Visitor
{
public:
    CustomsVisitor(){}
    ~CustomsVisitor(){}

  // Sunglasses
// Import tax is 2.9%
// VAT is 24%
double visit(Sunglasses* sunglasses)
{
    double price = sunglasses->getPrice();
    return price + (price * 0.029) + (price * 0.24);
}

// DVD
// Import tax is 3.5%
// VAT is 24%
double visit(DVD* dvd)
{
    double price = dvd->getPrice();
    return price + (price * 0.035) + (price * 0.24);
}

// Watch
// Import tax is constant 0.80€
// VAT is 24%
double visit(Watch* watch)
{
    double price = watch->getPrice();
    return price + 0.80 + (price * 0.24);
}

};


int main()
{
    cout << "-- Visitor Design Pattern demo --" << endl << endl;

    // Create Visitor
    CustomsVisitor* customsVisitor = new CustomsVisitor();

    // Create Products
    Product* sunglasses = new Sunglasses(50.0);
    Product* dvd = new DVD(15.5);
    Product* watch = new Watch(200.0);

    // Get the final prices via using the Visitor class
    cout << "FINAL PRICES FOR THE PRODUCTS" << endl;
    cout << "Sunglasses price: " << sunglasses->accept(customsVisitor)  << endl;
    cout << "DVD price: " << dvd->accept(customsVisitor) << endl;
    cout << "Watch price: " << watch->accept(customsVisitor) << endl;

    // Free resources
    delete customsVisitor;
    delete sunglasses;
    delete dvd;
    delete watch;

    return 0;
}

