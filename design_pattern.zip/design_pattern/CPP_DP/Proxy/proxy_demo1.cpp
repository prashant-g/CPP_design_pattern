#include<iostream>
#include<string>
using namespace std;

class Image {
public:
  virtual void display() = 0;
  virtual ~Image() = default;
};

class RealImage : public Image {
private:
  string filename;
  void load() const {
    cout << "Loading image: " << filename << endl;
  }

public:
  RealImage(string& filename) : filename(filename) {
    load();
  }
  void display() override {
    cout << "Displaying image: " << filename << endl;
  }
};

class ProxyImage : public Image {
private:
  string filename;
  RealImage* realImage;

public:
  ProxyImage(string &filename) : filename(filename), realImage(nullptr) {}
  
  ~ProxyImage() {
    delete realImage;
  }

  void display() override {
    if (realImage == nullptr) {
      // Lazy initialization
      realImage = new RealImage(filename);
    }
    realImage->display();
  }
};

int main() {
  string file_name("dogs.png");
  ProxyImage proxy(file_name);
  proxy.display();

  return 0;
}
