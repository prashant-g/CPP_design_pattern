#include <iostream>
using namespace std;
class IBox
{
public:
virtual void open() = 0;
virtual void close() = 0;
virtual ~IBox() {};
};

class SimpleBox : public IBox
{
	int *ptr;
	
public:
	SimpleBox()
	{
		ptr=new int[500000];
	}
	void open()
	{
	cout << "Opening box"<<endl;
	}
	void close()
	{
	cout << "Closeing box"<<endl;
	}

};



class ProxyBox : public IBox
{
public:
	ProxyBox(string sUserName, string sPwd):m_UserName(sUserName), m_Pwd(sPwd)
	{
	}

	virtual void open()
	{
	if (iSAuthenticated()) {
		cout << "\nAuthentication Success"<<endl;
		m_Box = new SimpleBox;
		m_Box->open();
	}
	else
		cout << "\nAuthentication Failure , You can't open the Box"<<endl;
	}
	virtual void close()
	{
	if (iSAuthenticated()) {
		cout << "\nAuthentication Success"<<endl;
		m_Box->close();
	}
	else
		cout << "\nAuthentication Failure , You can't close the Box"<<endl;
	}
private:
	bool iSAuthenticated()
	{
		bool bAuthenticated = false;
		if(m_UserName == "ge" && m_Pwd == "welcome")
			bAuthenticated=true;
		return bAuthenticated;

	}
private:
string m_UserName;
string m_Pwd;
SimpleBox *m_Box;
};

int main()
{
IBox* box = new ProxyBox("ge", "welcome");
box->open();
box->close();
//delete box;
} 
