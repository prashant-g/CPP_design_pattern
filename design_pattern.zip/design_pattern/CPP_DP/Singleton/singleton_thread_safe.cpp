#include <iostream>
#include<thread>
#include<mutex>
using namespace std;

mutex mylock;

class aSingletonClass
{
public:
  static aSingletonClass *getInstance( void )
  {
  	lock_guard<mutex> lock(mylock);//RAII 
	if(!instance_ )
  	{
		  instance_ = new aSingletonClass;
 	 }
	  return instance_;
 	
  }
  
  static void deleteInstance( void )
  {

    if(instance_)
      delete instance_;
    instance_ = NULL; //important as this can create dead reference problems
  }
void show()
  {
	cout<<a<<"  "<<b<<"   "<<c<<endl;
  }
private:
  int a,b,c;
  static aSingletonClass *instance_;
  aSingletonClass() {
    a=0;
  b=0;
  c=0;
  cout<<"constructor"<<endl;
  };
  
  ~aSingletonClass() {
  cout<<"destroctor"<<endl;
  };
  aSingletonClass(const aSingletonClass &);
  void operator =(const aSingletonClass &);
}; //mandatory or else error in compiling


aSingletonClass * aSingletonClass::instance_ = NULL;

void fun1()
{
  aSingletonClass *ptr1;
  ptr1=aSingletonClass::getInstance();
  printf("address ptr1 = %ld\n",ptr1);
}
void fun2()
{
  aSingletonClass *ptr2;
  ptr2=aSingletonClass::getInstance();
  printf("address ptr2 = %ld\n",ptr2);
}
void fun3()
{
  aSingletonClass *ptr3;
  ptr3=aSingletonClass::getInstance();
  printf("address ptr3 = %ld\n",ptr3);
}


int main()
{



	
thread t1(fun1);
thread t2(fun2);
thread t3(fun3);
t1.join(); 
t2.join(); 
t3.join();
 return 0;
}
