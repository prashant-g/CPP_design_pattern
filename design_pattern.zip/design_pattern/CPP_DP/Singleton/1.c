#include<stdio.h>
#include<string.h>

int main()
{
	printf("hello\n");
	int *p=NULL;
}
