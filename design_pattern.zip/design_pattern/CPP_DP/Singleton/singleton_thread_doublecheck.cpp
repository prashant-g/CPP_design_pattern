#include <iostream>
#include<thread>
#include<mutex>
using namespace std;
mutex m;
class aSingletonClass
{
public:
  static aSingletonClass* getInstance() {
    if (!instance_) {
        unique_lock<mutex> lock(m); // acquire lock
        if (!instance_) { 
            instance_ = new aSingletonClass();
        }
        lock.unlock(); // release lock
    }
    return instance_;
  }
  static void deleteInstance( void )
  {

    if(instance_)
      delete instance_;
    instance_ = NULL; //important as this can create dead reference problems
  }
void show()
  {
	cout<<a<<"  "<<b<<"   "<<c<<endl;
  }
private:
  static aSingletonClass *instance_;
  aSingletonClass() {
    a=0;
  b=0;
  c=0;
  cout<<"constructor"<<endl;
  };
  
  ~aSingletonClass() {
  cout<<"destroctor"<<endl;
  };
  aSingletonClass(const aSingletonClass &);
  int a,b,c;
}; //mandatory or else error in compiling


aSingletonClass * aSingletonClass::instance_ = NULL;

void fun1()
{
  aSingletonClass *ptr1;
  ptr1=aSingletonClass::getInstance();
  //cout<<"address ptr1 = "<<ptr1<<endl;
}
void fun2()
{
  aSingletonClass *ptr2;
  ptr2=aSingletonClass::getInstance();
  //cout<<"address ptr2 = "<<ptr2<<endl;
}
void fun3()
{
  aSingletonClass *ptr3;
  ptr3=aSingletonClass::getInstance();
  //cout<<"address ptr3 = "<<ptr3<<endl;
}


int main()
{
thread t1(fun1);
thread t2(fun2);
thread t3(fun3);
t1.join(); 
t2.join(); 
t3.join();
 return 0;
}
