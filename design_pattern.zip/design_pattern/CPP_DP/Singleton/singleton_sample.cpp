#include <iostream>
using namespace std;

class aSingletonClass
{
public:
  static aSingletonClass *getInstance( void )
  {
    if(!instance_)
      instance_ = new aSingletonClass;
    return instance_;
  }
  static void deleteInstance( void )
  {
    if(instance_)
      delete instance_;
    instance_ = NULL; //important as this can create dead reference problems
  }
void show()
  {
	cout<<a<<"  "<<b<<"   "<<c<<endl;
  }
private:
  static aSingletonClass *instance_;
  aSingletonClass() {
    a=10;
  b=20;
  c=30;
  cout<<"constructor"<<endl;
  };
  
  ~aSingletonClass() {
  cout<<"destroctor"<<endl;
  };
  aSingletonClass(const aSingletonClass &);
  int a,b,c;
};


aSingletonClass * aSingletonClass::instance_ = NULL;

int main()
{
	aSingletonClass *ptr1,*ptr2,*ptr3;
  ptr1=aSingletonClass::getInstance();
  ptr1->show();
  cout<<"address ptr1 = "<<ptr1<<endl;
  ptr2=aSingletonClass::getInstance();
 cout<<"address ptr2 = "<<ptr2<<endl;
 ptr2->show();
 ptr3=aSingletonClass::getInstance();
  cout<<"address ptr3 = "<<ptr3<<endl;
  ptr3->show();
 aSingletonClass::deleteInstance(); 
 return 0;
}
