#include <iostream>
using namespace std;

class Stack
{
    int items[10];
    int tos;
  public:
    Stack()
    {
        tos=  - 1;
    }
    void push(int in)
    {
        items[++tos] = in;
    }
    int pop()
    {
        return items[tos--];
    }
    bool isEmpty()
    {
        return (tos ==  - 1);
    }
    int size()
    {
	    return tos+1;
    }

class Iterator
{
    Stack &stk;
    int index;
  public:
    //StackIter(Stack &s): stk(s)
    Iterator(Stack &s): stk(s)
    {
        index = 0;
    }
    void operator++()
    {
        index++;
    }
    bool operator()()
    {
        return index != stk.tos + 1;
    }
    int operator *()
    {
        return stk.items[index];
    }
};
};


int main()
{
	Stack s1;
	s1.push(11);
	s1.push(22);
	s1.push(33);
	s1.push(44);
	s1.push(55);
	Stack::Iterator it(s1);
	while(it())
	{
		cout<<*it<<endl;
		++it;
	}


}
