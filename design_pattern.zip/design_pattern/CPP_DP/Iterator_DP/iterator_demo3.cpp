#include<iostream>
#include<string>
#include<vector>

using namespace std;

class Iterator;
class ConcreteIterator;

class Aggregate
{
	public:
		virtual Iterator *CreateIterator()=0;
};

class ConcreteAggregate : public Aggregate//Stack
{
	vector<string> *elements;

public:
	ConcreteAggregate()
	{
		elements=new vector<string>();
	}
	Iterator *CreateIterator();

	int Size()
	{
		return elements->size();
	}
	void add(string value)
	{
		elements->push_back(value);
	}
	string GetElements(int index)
	{
		return elements->at(index);
	}
};

class Iterator
{
	public:
		virtual void First()=0;
		virtual void Next()=0;
		virtual bool IsDone()=0;
		virtual string CurrentItem()=0;
};


class ConcreteIterator : public Iterator//StackIterator
{
	ConcreteAggregate *aggregateObj;
	int currentElement;
public:
	ConcreteIterator(ConcreteAggregate *obj)
	{
	aggregateObj=obj;
	currentElement=0;
	}
	void First()
	{
		currentElement=0;
	}
	void Next()
	{
		currentElement++;
	}
	bool IsDone()
	{
		if(currentElement >= aggregateObj->Size())
			return true;
		else
			return false;
	}
	string CurrentItem()
	{
		return aggregateObj->GetElements(currentElement);
	}
};

Iterator *ConcreteAggregate::CreateIterator()
{
	return new ConcreteIterator(this);
}


int main()
{
	ConcreteAggregate *obj=new ConcreteAggregate();
	obj->add("Rahul");
	obj->add("Sachin");
	obj->add("Sourav");
	obj->add("Laxman");
	Iterator *itr=obj->CreateIterator();
	for(itr->First();!(itr->IsDone());itr->Next())
	{
		cout<<itr->CurrentItem()<<endl;
	}
	return 0;
}

