#include<iostream>
#include<stdlib.h>
using namespace std;
struct node
{
int info;
struct node *next;
};



class Stack
{
	node *head;
public :
	Stack()
	{
		head=NULL;
	}

	void push(int num)//554
	{
		node *temp=NULL,*cur;
		cur=head;
		temp=(node *)malloc(sizeof(node));
		temp->info=num;
		temp->next=NULL;
		if(head == NULL)
		{
			head=temp;
		}
		else
		{
		
			while(cur->next!=NULL)
				cur=cur->next;
			cur->next=temp;
			
		}
	}



int size()
{
	int count=0;
	node *p;
	p=head;
	while(p!=NULL)
	{
		count++;
		p=p->next;

	}
	return count;
}


int pop()
{
	node *p,*prev;
	p=head;
	if(head == NULL)
	{
		return 0;
	}
	else if(p->next == NULL)//1
	{
		head=NULL;
		int num = p->info;
		free(p);
		return num;
	}
	else//2,3,4
	{		
		
		while(p->next!=NULL)
		{	prev=p;
			p=p->next;
		}

		prev->next=NULL;
		int num=p->info;
		free(p);
		return num;
	}
}


void clean_up()
{
	node *p,*p1;

	p=head;
	while(p!=NULL)
	{
		p1=p;
		p=p->next;
	free(p1);
	}
}

class iterator
{
	Stack *s;
	node *current;

public:
	iterator(Stack *arg)//&s1
	{
		s=arg;//s=&s1
		current=s->head;
	}
	int operator *()
	{
		if(current != NULL)
			return current->info;
		else
			return -1;
	}

	void operator ++()
	{
		current=current->next;
	}

	bool operator ()()
	{
		if(current!= NULL)
			return true;
		else
			return false;

	}

};//end of iterator


};//end Stack class

int main()
{
	Stack s1;
	int choice,num,pos,dval;
	while(1)
	{
		cout<<"1 :: Push element to Stack\n";
		
		cout<<"2 :: Traverse\n";
		cout<<"3 :: Pop stack\n";
		cout<<"4 :: Size\n";
		cout<<"0 :: Exit\n";
		scanf("%d",&choice);
		if(choice == 1){
			cout<<"Enter Element to Push :: ";
			cin>>num;//554
			s1.push(num);
			}
		else if(choice == 2){
				cout<<"stack iteration"<<endl;		
				for(Stack::iterator it(&s1); it();++it)//it.()()
				{
					cout<<*it<<endl;
				}	
			
		}
		
		else if(choice == 3){
			if(dval=s1.pop())
				cout<<"popped element is  "<<dval<<endl;
			else
				cout<<"Stack is empty\n";
			}
		else if(choice == 4)
			cout<<"Size of stack = "<<s1.size()<<endl;
		else if(choice == 0){

				cout<<"Exiting Application\n";
				s1.clean_up();
				exit(0);
		}	
		else{
		cout<<"Wrong choice\n";
		cout<<"Please check the ment and enter accordingly\n";
			}
		}
	}
