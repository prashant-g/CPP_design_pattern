#include<iostream>
using namespace std;

class Time
{
	int hr,min,sec;
public:
	Time(int h,int m, int s)
	{
		hr=h;
		min=m;
		sec=s;
	}

friend ostream & operator <<(ostream &os,Time &t)
{
	return os<<t.hr<<"::"<<t.min<<"::"<<t.sec<<endl;	
}
Time operator ++(int)//this->t1
{
	int a=this->hr++;
	int b=this->min++;
	int c=this->sec++;
	return Time(a,b,c);
}
Time operator ++()//this->t1
{
  int a=++this->hr;
  int b=++this->min;
  int c=++this->sec;
  return Time(a,b,c);
}

};


int main(){
	Time t1(11,12,45),t2(0,0,0);
	cout<<t1;
	cout<<t2;
	t2=t1++;//t1.++(int)
	cout<<"after pre increament"<<endl;
	cout<<t1;
	cout<<t2;


}
