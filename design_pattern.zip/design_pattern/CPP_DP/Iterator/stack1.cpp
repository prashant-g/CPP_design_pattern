#include<iostream>
#include<stdlib.h>
using namespace std;
struct node
{
int info;
struct node *next;
};



class Stack
{
	node *head;
public :
	Stack()
	{
		head=NULL;
	}

	void push(int num)//554
	{
		node *temp=NULL,*cur;
		cur=head;
		temp=(node *)malloc(sizeof(node));
		temp->info=num;
		temp->next=NULL;
		if(head == NULL)
		{
			head=temp;
		}
		else
		{
		
			while(cur->next!=NULL)
				cur=cur->next;
			cur->next=temp;
			
		}
	}



int size()
{
	int count=0;
	node *p;
	p=head;
	while(p!=NULL)
	{
		count++;
		p=p->next;

	}
	return count;
}


int pop()
{
	node *p,*prev;
	p=head;
	if(head == NULL)
	{
		return 0;
	}
	else if(p->next == NULL)//1
	{
		head=NULL;
		int num = p->info;
		free(p);
		return num;
	}
	else//2,3,4
	{		
		
		while(p->next!=NULL)
		{	prev=p;
			p=p->next;
		}

		prev->next=NULL;
		int num=p->info;
		free(p);
		return num;
	}
}


void clean_up()
{
	node *p,*p1;

	p=head;
	while(p!=NULL)
	{
		p1=p;
		p=p->next;
	free(p1);
	}
}

class iterator
{
	Stack *s;
	node *current;

public:
	iterator(Stack *arg)//&s1
	{
		s=arg;//s=&s1
		current=s->head;
	}
	int operator *()
	{
		if(current != NULL)
			return current->info;
		else
			return -1;
	}

	void operator ++()
	{
		current=current->next;
	}

	bool operator ()()
	{
		if(current!= NULL)
			return true;
		else
			return false;

	}

};//end of iterator


};//end Stack class



bool operator ==(Stack s1, Stack s2)
{
	for(Stack::iterator it1(&s1),it2(&s2);it1() && it2();++it1,++it2)
	{
		if(*it1 != *it2)
			return false;
	}
	return true;
}



int main()
{
	Stack s1, s2;
	s1.push(11);
	s1.push(22);
	s1.push(33);
	s1.push(44);
	s1.push(55);
	
	s2.push(11);
	s2.push(22);
	s2.push(33);
	s2.push(44);
	s2.push(55);


	if(s1 == s2)//==(s1,s2)
	{
		cout<<"both stacks have the same values"<<endl;
	}
	else
	{
		cout<<"both stacks are not same"<<endl;
	}
}
