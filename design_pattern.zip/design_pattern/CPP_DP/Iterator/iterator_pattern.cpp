#include <iostream>
using namespace std;

class Stack
{
    int items[10];
    int sp;
  public:
    Stack()
    {
        sp =  - 1;
    }
    void push(int in)
    {
        items[++sp] = in;
    }
    int pop()
    {
        return items[sp--];
    }
    bool isEmpty()
    {
        return (sp ==  - 1);
    }
    int size()
    {
	    return sp+1;
    }
    int getIndex()
    {
	    return sp;
    }
    int getItem(int index)
    {
	    return items[index];
    }
};

class StackIter
{
    Stack &stk;
    int index;
  public:
    StackIter(Stack &s): stk(s)
    {
        index = 0;
    }
    void operator++()
    {
        index++;
    }
    bool operator()()
    {
        return index != stk.getIndex() + 1;
    }
    int operator *()
    {
        return stk.getItem(index);
    }
};

bool operator == (Stack &l,  Stack &r)
{
  StackIter itl(l), itr(r);
  for (; itl(); ++itl, ++itr)//itl.[](
    if (*itl !=  *itr)
      break;
  return !itl() && !itr();
}

int main()
{
  Stack s1;
  int i;
  for (i = 1; i < 5; i++)
    s1.push(i*i*i);

  Stack s2(s1), s3(s1), s4(s1), s5(s1);
  s3.pop();
  s5.pop();
  s4.push(2);
  s5.push(9);
  cout << "1 == 2 is " << (s1 == s2) << endl;//==(s1,s2)
  cout << "1 == 3 is " << (s1 == s3) << endl;
  cout << "1 == 4 is " << (s1 == s4) << endl;
  cout << "1 == 5 is " << (s1 == s5) << endl;
}
