#include <iostream>
using namespace std;

class Stack
{
    int items[10];
    int tos;
  public:
    Stack()
    {
        tos =  - 1;
    }
    void push(int in)
    {
        items[++tos] = in;
    }
    int pop()
    {
        return items[tos--];
    }
    bool isEmpty()
    {
        return (tos ==  - 1);
    }
    int size()
    {
	    return tos+1;
    }
    int getIndex()
    {
	    return tos;
    }
    int getItem(int index)
    {
	    return items[index];
    }
};


class StackIterator 
{
    Stack *stk;
    int index;
  public:
    StackIterator(Stack *s)
    {
	stk=s;
        index = 0;
    }
    void operator++()
    {
        index++;
    }
    bool operator()()
    {
        return index != stk->getIndex() + 1;
    }
    int operator *()
    {
        return stk->getItem(index);
    }
};

int main() {
	Stack *stack1=new Stack;
  	for (int i = 0; i < 10; i++)
	  	stack1->push(i*i*i);
	
	StackIterator it(stack1);

	while(it()){
		cout<<*it<<endl;
		++it;
	}
}
