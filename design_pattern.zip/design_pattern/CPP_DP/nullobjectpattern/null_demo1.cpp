// strategizedLockingRuntime.cpp

#include <iostream>
#include <mutex>
#include <shared_mutex>
#include<thread>
class Lock {
public:
    virtual void lock() const = 0;
    virtual void unlock() const = 0;
};

class StrategizedLocking {
    Lock& lock;                                  // (1)
public:
    StrategizedLocking(Lock& l): lock(l){
        lock.lock();                             // (2)
    }
    ~StrategizedLocking(){
        lock.unlock();                           // (3)
    }
};

struct NullObjectMutex{                          
    void lock(){}
    void unlock(){}
};

class NoLock : public Lock {                     // (4)
    void lock() const override {
        std::cout << "NoLock::lock: " << '\n';
        nullObjectMutex.lock();
    }
    void unlock() const override {
        std::cout << "NoLock::unlock: " << '\n';
         nullObjectMutex.unlock();
    }
    mutable NullObjectMutex nullObjectMutex;     // (9)
};

class ExclusiveLock : public Lock {              // (5)
    void lock() const override {
        std::cout << "    ExclusiveLock::lock: " << '\n';
        mutex.lock();
    }
    void unlock() const override {
        std::cout << "    ExclusiveLock::unlock: " << '\n';
        mutex.unlock();
    }
    mutable std::mutex mutex;                    // (10)
};

class SharedLock : public Lock {                 // (6)
    void lock() const override {
        std::cout << "        SharedLock::lock_shared: " << '\n';
        sharedMutex.lock_shared();                // (7)
    }
    void unlock() const override {
        std::cout << "        SharedLock::unlock_shared: " << '\n';
        sharedMutex.unlock_shared();              // (8)
    }
    mutable std::shared_mutex sharedMutex;        // (11)
};

int main() {
    
    std::cout << '\n';
    
    NoLock noLock;
    StrategizedLocking stratLock1{noLock};
    
    {
        ExclusiveLock exLock;
        StrategizedLocking stratLock2{exLock};
        {
            SharedLock sharLock;
            StrategizedLocking startLock3{sharLock};
        }
    }
    
    std::cout << '\n';
    
}
