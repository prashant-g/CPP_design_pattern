#include<iostream>
#include<string>

using namespace std;

class Customer {
	public:
    virtual string getName()=0;
};

class RealCustomer : public Customer {
	private :
		string name;

	public :
		RealCustomer(string name) {
        this->name = name;
    }

    string getName() {
        return name;
    }
};

class NullCustomer : public Customer {
	public :
		string getName() {
        return "Not Available";
    }
};


 class CustomerFactory {
	 public :
		 static Customer * getCustomerById(int id) {
        if (id == 123) {
            return new RealCustomer("Gang of Four");
        } else {
            return new NullCustomer();
        }
    }
};


int main()
{
Customer *customer = CustomerFactory::getCustomerById(122);
cout<<customer->getName()<<endl;
}
