#include<iostream>
#include<string>

using namespace std;
class User
{
protected:
	int id;
	string name;
public:

	virtual bool hasAccess()=0;
	virtual string getName()=0;
	virtual int getID()=0;
};

class RealUser : public  User {
public:

  RealUser(int id, string name) {
    this->id = id;
    this->name = name;
  }

  bool hasAccess() {
    return true;
  }
	
  string getName() {
	  return name;
  }
  int getID() {
  	return id;
  }

};

class NullUser : public User {
public:
  NullUser() {
    this->id = -1;
    this->name = "Guest";
  }

  bool hasAccess() {
    return false;
  }
  string getName() {
	  return name;
  }
  int getID() {
  	return id;
  }

};


int user_ids[]={111,222,333,444,555,666,777,888,999};
string user_names[]={"Anil","Sachin","Vijay","Rohith","Ajay","Rashmi","Vinay","Suman","Prem"};


class UserFactory
{

	public :
	static User * getUser(int id)
	{
		for(int index=0;index < sizeof(user_ids)/sizeof(user_ids[0]);index++)
		{
			if(user_ids[index] == id)
			{
				return new RealUser(id,user_names[index]);
			}
		}
		return new NullUser;
	}
};


int main()
{
	User *user1=UserFactory::getUser(444);
	if(user1->hasAccess())
		cout<<"Name :: "<<user1->getName()<<" ID  :: "<<user1->getID()<<endl;
	User *user2=UserFactory::getUser(666);
	if(user2->hasAccess())
		cout<<"Name :: "<<user2->getName()<<" ID  :: "<<user2->getID()<<endl;
	User *user3=UserFactory::getUser(1234);
	if(user3->hasAccess())
		cout<<"Name :: "<<user3->getName()<<" ID  :: "<<user3->getID()<<endl;
}

