#include<iostream>
#include<string>
#include<vector>
using namespace std;

class Product
{
	public:
    vector<string> parts_;
virtual void ListParts() const=0;
};

class ProductConcrete : public Product{
    public:
    void ListParts() const{
        cout << "Product parts: ";
        for (auto i=0;i<parts_.size();i++){
                cout << parts_[i]<<"  ";
            }
       cout << "\n\n"; 
    }
};


class Builder{
    public:
    virtual ~Builder()
    {
    }
    virtual void ProducePartA() const =0;
    virtual void ProducePartB() const =0;
    virtual void ProducePartC() const =0;
};
class ConcreteBuilder : public Builder{
    private:

    Product* product;

    public:

    ConcreteBuilder(){
        this->product= new ProductConcrete();
    }

    ~ConcreteBuilder(){
        delete product;
    }


    void ProducePartA() const override{
        this->product->parts_.push_back("PartA1");
    }

    void ProducePartB()const override{
        this->product->parts_.push_back("PartB1");
    }

    void ProducePartC()const override{
        this->product->parts_.push_back("PartC1");
    }

    Product* GetProduct() {
	return this->product;
    }
};

class Director{
    private:
    Builder* builder;

    public:

    void set_builder(Builder* builder){
        this->builder=builder;
    }


    void BuildMinimalViableProduct(){
        this->builder->ProducePartA();
    }
    
    void BuildFullFeaturedProduct(){
        this->builder->ProducePartA();
        this->builder->ProducePartB();
        this->builder->ProducePartC();
    }
};
int main(){
    Director* director1= new Director();
    ConcreteBuilder* builder1 = new ConcreteBuilder();
    director1->set_builder(builder1);
    cout << "Standard basic product:\n"; 
    director1->BuildMinimalViableProduct();
    
    Product* p= builder1->GetProduct();
    p->ListParts();

    cout << "Standard full featured product:\n"; 
    Director* director2= new Director();
    ConcreteBuilder* builder2 = new ConcreteBuilder();
    director2->set_builder(builder2);
    director2->BuildFullFeaturedProduct();

    p= builder2->GetProduct();
    p->ListParts();

    // Remember, the Builder pattern can be used without a Director class.
    cout << "Custom product:\n";
    ConcreteBuilder* builder3 = new ConcreteBuilder();
    builder3->ProducePartA();
    builder3->ProducePartC();
    p=builder3->GetProduct();
    p->ListParts();

    delete builder1;
    delete builder2;
    delete builder3;
    delete director1;
    delete director2;
    return 0;    
}
