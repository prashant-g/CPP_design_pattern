#include<iostream>
#include<string>
#include<vector>
using namespace std;

class Packing {
	public:
	       virtual	string pack()=0;
};
class Wrapper : public Packing {

	public:
		string pack() {
	      return "Wrapper";
	   }
	};

class Bottle : public Packing {

	public :
		string pack() 
		{
	      return "Bottle";
	   	}
	};

class Item {
	public :
	   virtual string name()=0;
	   virtual Packing * packing() = 0;
	   virtual float price()=0;	
	};

class Burger: public Item {
	public :
		Packing * packing() 
		{
	      return (new Wrapper);
	   	}
	};

class ColdDrink : public Item {

	public :
		Packing * packing() {
       		return (new Bottle);
	}

};



class VegBurger : public Burger {
	public :
		float price() {
	      return 25.0f;
	   	}

	  
	   string name() {
	      return "Veg Burger";
	   }
	};

class ChickenBurger : public Burger {

	public:
	       	float price() {
	      return 50.5f;
	   }

	   string name() {
	      return "Chicken Burger";
	   }
	};

class Coke : public ColdDrink {

	public:
	float price() {
	      return 30.0f;
	   }

	  string name() {
	      return "Coke";
	   }
	};


class Pepsi : public ColdDrink {
	public:
		float price() {
	      return 35.0f;
	   }

	   string name() {
	      return "Pepsi";
	   }
};


class Meal {
	private :
		vector<Item * > items;	

	public :
		void addItem(Item *item){
      items.push_back(item);
   }

   	float getCost()
	{
      float cost = 0.0f;
      for (int i=0;i<items.size();i++) {
         cost += items[i]->price();
      }		
      return cost;
   }

   	void showItems(){
   
      for (int i=0;i<items.size();i++) {
         cout<<"Item : " <<items[i]->name()<<endl;
         cout<<"Packing : " << items[i]->packing()->pack()<<endl;
         cout<<" Price : " <<items[i]->price()<<endl;
      }		
   }	
};


class MealBuilder {

	public :
		Meal prepareVegMeal ()
		{
	      Meal meal ;
	      meal.addItem(new VegBurger);
	      meal.addItem(new Coke);
	      return meal;
	   }   

	   Meal prepareNonVegMeal (){
	      Meal meal ;
	      meal.addItem(new ChickenBurger);
	      meal.addItem(new Pepsi);
	      return meal;
	   }
	};

int main() 
{
	   
	      MealBuilder mealBuilder;

	      Meal vegMeal = mealBuilder.prepareVegMeal();
	      cout<<"Veg Meal"<<endl;
	      vegMeal.showItems();
	      cout<<"Total Cost: "<< vegMeal.getCost()<<endl;

	      Meal nonVegMeal = mealBuilder.prepareNonVegMeal();
	      cout<<"\n\nNon-Veg Meal"<<endl;
	      nonVegMeal.showItems();
	      cout<<"Total Cost: " <<nonVegMeal.getCost()<<endl;
 }

