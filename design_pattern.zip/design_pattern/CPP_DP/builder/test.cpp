#include<iostream>
using namespace std;


class Emp
{
	int eid;
	float sal;
	char grade;

public:
	void setEmp(int eid,float sal, char grade)
	{
		this->eid=eid;
		this->sal=sal;
		this->grade=grade;
	}
	void showEmpData()  const
	{
		cout<<"EID = "<<eid<<endl;
		cout<<"Sal = "<<sal<<endl;
		cout<<"Grade = "<<grade<<endl;
	}
};


int main()
{
	Emp e1;
	e1.setEmp(12345,99000,'A');
	e1.showEmpData();
}
