#include <iostream>

class State {
public:
    virtual ~State() = default;
    virtual void Execute() = 0;
};

class ConcreteStateA : public State {
    void Execute() override {
        std::cout << "Doing work in state A" << std::endl;
    }
};

class ConcreteStateB : public State {
    void Execute() override {
        std::cout << "Doing work in state B" << std::endl;
    }
};

class Context {
private:
    State* state{nullptr};
public:
    void SetState(State* new_state){
        if(state!=nullptr) {
            delete state;
        }
        state = new_state;
    }

    void PerformWork() {
        state->Execute();
    }
};

void ClientCode() {
    Context c;
    c.SetState(new ConcreteStateA());
    c.PerformWork();
    c.SetState(new ConcreteStateB());
    c.PerformWork();
}

int main() {
    ClientCode();
    return 0;
}
