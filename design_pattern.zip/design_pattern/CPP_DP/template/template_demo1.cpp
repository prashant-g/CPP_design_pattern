#include <iostream>

class VehicleTemplate {
public:
    // Template method defines the algorithm structure
    void buildVehicle() {
        assembleBody();
        installEngine();
        addWheels();
        std::cout << "Vehicle is ready!\n";
    }

    // Abstract methods to be implemented by concrete classes
    virtual void assembleBody() = 0;
    virtual void installEngine() = 0;
    virtual void addWheels() = 0;
};
class Truck : public VehicleTemplate {
public:
    void assembleBody() override {
        std::cout << "Assembling truck body.\n";
    }

    void installEngine() override {
        std::cout << "Installing truck engine.\n";
    }

    void addWheels() override {
        std::cout << "Adding 16 wheels to the truck.\n";
    }
};


class Car : public VehicleTemplate {
public:
    void assembleBody() override {
        std::cout << "Assembling car body.\n";
    }

    void installEngine() override {
        std::cout << "Installing car engine.\n";
    }

    void addWheels() override {
        std::cout << "Adding 4 wheels to the car.\n";
    }
};

class Motorcycle : public VehicleTemplate {
public:
    void assembleBody() override {
        std::cout << "Assembling motorcycle frame.\n";
    }

    void installEngine() override {
        std::cout << "Installing motorcycle engine.\n";
    }

    void addWheels() override {
        std::cout << "Adding 2 wheels to the motorcycle.\n";
    }
};

// Step 3: Client Code
int main() {
    std::cout << "Building a truck:\n";
    Truck truck;
    truck.buildVehicle();
    std::cout << "Building a Car:\n";
    Car car;
    car.buildVehicle();

    std::cout << "\nBuilding a Motorcycle:\n";
    Motorcycle motorcycle;
    motorcycle.buildVehicle();

    return 0;
}
