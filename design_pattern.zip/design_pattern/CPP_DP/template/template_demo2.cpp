#include<iostream>
using namespace std;
//template abstarct
class DataSynchronizer
{
	public:
	void Synchronize()
        {
            OpenSource();
            OpenDestination();
            TransferData();
            CloseSource();
            CloseDestination();
        }
	virtual void OpenSource()=0;
        virtual void OpenDestination()=0;
        virtual void TransferData()=0;
        virtual void CloseSource()=0;
        virtual void CloseDestination()=0;
    };
    //Concrete Implementations:
    //For Database to File synchronization
class DatabaseToFileSynchronizer : public DataSynchronizer
{
public :
	void OpenSource()
        {
            cout<<"Opening database connection...";
        }
        void OpenDestination()
        {
            cout<<"Opening file for writing..."<<endl;
        }
        void TransferData()
        {
            cout<<"Reading data from database and writing to file..."<<endl;
        }
        void CloseSource()
        {
            cout<<"Closing database connection..."<<endl;
        }
        void CloseDestination()
        {
            cout<<"Closing file..."<<endl;
        }
    };
    //For API to Database synchronization
class ApiToDatabaseSynchronizer : public DataSynchronizer
    {
        void OpenSource()
        {
            cout<<"Connecting to API..."<<endl;
        }
        void OpenDestination()
        {
            cout<<"Opening database connection for writing..."<<endl;
        }
        void TransferData()
        {
            cout<<"Fetching data from API and inserting into database..."<<endl;
        }
        void CloseSource()
        {
            cout<<"Closing API connection..."<<endl;
        }
        void CloseDestination()
        {
            cout<<"Closing database connection..."<<endl;
        }
    };
    
    // Testing the Template Method Design Pattern
    // Client Code
int main()
        {
            DataSynchronizer *dbToFileSync = new DatabaseToFileSynchronizer;
            dbToFileSync->Synchronize();
            DataSynchronizer *apiToDbSync = new ApiToDatabaseSynchronizer;
            apiToDbSync->Synchronize();
        }
