#include <iostream>
#include <string>
#include <vector>

// Memento class to store the text state
class TextMemento {
public:
    TextMemento(const std::string& text) : text_(text) {}

    const std::string& getText() const {
        return text_;
    }

private:
    std::string text_;
};

// Originator class representing the text editor
class TextEditor {
public:
    void setText(const std::string& text) {
        text_ = text;
    }

    const std::string& getText() const {
        return text_;
    }

    // Create a memento to save the current state
    TextMemento createMemento() {
        return TextMemento(text_);
    }

    // Restore the state from a memento
    void restoreMemento(const TextMemento& memento) {
        text_ = memento.getText();
    }

private:
    std::string text_;
};

int main() {
    TextEditor editor;
    std::vector<TextMemento> history;

    editor.setText("Hello, World!");
    history.push_back(editor.createMemento());

    editor.setText("Goodbye!");
    history.push_back(editor.createMemento());

    std::cout << "Current Text: " << editor.getText() << std::endl;

    // Undo
    editor.restoreMemento(history[0]);
    std::cout << "After Undo: " << editor.getText() << std::endl;

    // Redo
    editor.restoreMemento(history[1]);
    std::cout << "After Redo: " << editor.getText() << std::endl;

    return 0;
}
