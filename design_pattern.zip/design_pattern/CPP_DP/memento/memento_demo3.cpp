#include <iostream>

// Memento class to store the configuration state
class ConfigMemento {
public:
    ConfigMemento(int fontSize, int theme) : fontSize_(fontSize), theme_(theme) {}

    int getFontSize() const {
        return fontSize_;
    }

    int getTheme() const {
        return theme_;
    }

private:
    int fontSize_;
    int theme_;
};

// Originator class representing the configuration manager
class ConfigurationManager {
public:
    void setConfiguration(int fontSize, int theme) {
        fontSize_ = fontSize;
        theme_ = theme;
    }

    int getFontSize() const {
        return fontSize_;
    }

    int getTheme() const {
        return theme_;
    }

    // Create a memento to save the current configuration state
    ConfigMemento createMemento() {
        return ConfigMemento(fontSize_, theme_);
    }

    // Restore the configuration state from a memento
    void restoreMemento(const ConfigMemento& memento) {
        fontSize_ = memento.getFontSize();
        theme_ = memento.getTheme();
    }

private:
    int fontSize_;
    int theme_;
};

int main() {
    ConfigurationManager configManager;
    configManager.setConfiguration(12, 1);

    // Save the configuration state
    ConfigMemento save1 = configManager.createMemento();

    configManager.setConfiguration(16, 2);

    std::cout << "Current Configuration - Font Size: " << configManager.getFontSize() << ", Theme: " << configManager.getTheme() << std::endl;

    // Restore the configuration state from the saved memento
    configManager.restoreMemento(save1);

    std::cout << "Restored Configuration - Font Size: " << configManager.getFontSize() << ", Theme: " << configManager.getTheme() << std::endl;

    return 0;
}
