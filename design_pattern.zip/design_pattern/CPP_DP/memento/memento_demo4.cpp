#include<iostream>
#include<string>
#include<vector>
using namespace std;
class State {
public:
    int value;
    State(int val) : value(val) {}
};

class Memento {
private:
    State state;

public:
    Memento(const State& state) : state(state) {}

    State getState() const {
        return state;
    }
};


class Originator {
private:
    State state;

public:
    Originator(int value) : state(value) {}

    void setState(int value) {
        state.value = value;
    }

    int getState() const {
        return state.value;
    }

    Memento createMemento() const {
        return Memento(state);
    }

    void restore(const Memento& memento) {
        state = memento.getState();
    }
};



class Caretaker {
private:
    std::vector<Memento> mementos;

public:
    void addMemento(const Memento& memento) {
        mementos.push_back(memento);
    }

    Memento getMemento(int index) const {
        if (index < 0 || index >= mementos.size()) {
            throw std::out_of_range("Invalid memento index");
        }
        return mementos[index];
    }
};

int main() {
    Originator originator(42);
    Caretaker caretaker;

    std::cout << "Initial State: " << originator.getState() << std::endl;

    // Save the state
    caretaker.addMemento(originator.createMemento());

    // Change the state
    originator.setState(84);
    std::cout << "State after change: " << originator.getState() << std::endl;

    // Restore the state
    originator.restore(caretaker.getMemento(0));
    std::cout << "State after restore: " << originator.getState() << std::endl;

    return 0;
}
