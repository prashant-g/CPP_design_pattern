// COMBasics.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include<Windows.h>
#include<iostream>
using namespace std;
#define IID_IX 101
#define IID_IY 102
#define IID_IZ 103
class ICommon // IUnknown
{
public:
	virtual UINT CheckInterfaceSupport(UINT id, void **p)=0;//QueryInterface
	virtual UINT IncrementCounter() = 0;//AddRef
	virtual UINT DecrementCounter() = 0;//Release

};
class IX: public ICommon
{
public:
	virtual void fx() = 0;
};
class IY : public ICommon
{
public:
	virtual void fy() = 0;
};
class IZ : public ICommon
{
public:
	virtual void fz() = 0;
};

class CA :public IX,public IY
{
	int refcount;
public:
	CA() :refcount(0)
	{
		cout << "constr" << endl;
	}
	~CA()
	{
		cout << "destr" << endl;
	}
	void fx()
	{
		cout << "fx" << endl;
	}
	void fy()
	{
		cout << "fy" << endl;
	}
	UINT CheckInterfaceSupport(UINT id, void **p)
	{
		if (id == IID_IX)
			*p = this;
		if (id == IID_IY)
			*p = this;
		else
			return 0;
		((ICommon*)*p)->IncrementCounter();
		return 1;

	}
	UINT IncrementCounter()
	{
		refcount++;
		cout << refcount << endl;
		return refcount;
	 }
	UINT DecrementCounter()
	{
		refcount--;
		cout << refcount << endl;
		if (refcount == 0)
			delete this;
		return refcount;
	 }
};

class Factory // ClassFactory
{
public:
	/*static IX* Create()
	{
		CA *a = new CA();
		return a;
	}*/

	static void Create(void **p) 
	{
		*p = new CA();
		((ICommon*)*p)->IncrementCounter();
	}
};
int main()
{
	////IX *x = new CA();
	//IX *x = Factory::Create();
	//x->fx();

	//IY * = Factory::Create();
	//y->fy();

	IX *x = NULL;
	Factory::Create((void**)&x);
	if (x != NULL)
		x->fx();

	IY *y = NULL;
	x->CheckInterfaceSupport(IID_IY, (void**)&y);
	if(y!=NULL)
		y->fy();

	IZ *z = NULL;
	x->CheckInterfaceSupport(IID_IZ, (void**)&z);

	x->DecrementCounter();
	y->DecrementCounter();

    return 0;
}


