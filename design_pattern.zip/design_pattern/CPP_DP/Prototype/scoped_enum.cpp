#include<iostream>
using namespace std;

int main()
{
	enum class color{RED,GREEN, BLUE, YELLOW};

	int RED=6;

}
