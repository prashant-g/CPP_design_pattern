#include<iostream>
#include<string>
#include<unistd.h>
#include<string.h>
using namespace std;

enum class ENGINE_TYPE :int{
    PETROL = 0,
    DIESEL,
    CNG,
    ELECTRIC
};

class Engine{
    public:
       ENGINE_TYPE type;
       int horsePower;
       int numCylinders;
      Engine(){} 
       Engine(ENGINE_TYPE type, int horsePower, int numCylinders)
        :type(type), horsePower(horsePower), numCylinders(numCylinders)
        {
		cout<<"creating engine"<<endl;
	sleep(5);

	}
       
       Engine* clone(){
           Engine *newEngine=new Engine();
	   memcpy(newEngine,this,sizeof(Engine));
           return newEngine;
       }
       void showEngine()
       {
	       cout<<"Engine Type :: "<<int(type)<<endl;
	       cout<<"horse power :: "<<horsePower<<endl;
	       cout<<"num of cylinders :: "<<numCylinders<<endl;
       }
};

enum class TYRE_THREAD_PATTERN :int{
    UNIDIRECTIONAL,
    ASYMMETRICAL,
    CONVENCTIONAL
};
enum class TYRE_TYPE : int{
    TUBE_LESS,
    TUBE_TYPE
};

class Tyre{
    public:
        int diameter;
        TYRE_THREAD_PATTERN threadPattern;
        TYRE_TYPE type;
        Tyre(){}
        Tyre(TYRE_THREAD_PATTERN threadPattern, TYRE_TYPE type, int diameter)
            :diameter(diameter), threadPattern(threadPattern), type(type)
            {
		cout<<"creating tyre"<<endl;
		sleep(5);
	    }
        
        Tyre* clone(){
            Tyre *newTyre = new Tyre();//(this->threadPattern, this->type, this->diameter);
            
	     memcpy(newTyre,this,sizeof(Tyre));
	    return newTyre;
        }
       
	void showTyre()
       {
	       cout<<"Diameter :: "<<diameter<<endl;
	      cout<<"thread pattern :: "<<int(threadPattern)<<endl;
	       cout<<"tyre type :: "<<int(type)<<endl;
       }
};

enum class CAR_COLOR :int{
    RED,
    BLACK,
    WHITE,
    BLUE
};
class Car{
    public:
        Tyre *tyre;
        Engine *engine;
        CAR_COLOR color;
        
        Car(Tyre *tyre, Engine *engine, CAR_COLOR color)
            :tyre(tyre), engine(engine), color(color)
            {}
        
        Car* clone(){
            Car *newCar = new Car(
                this->tyre->clone(),
                this->engine->clone(),
                this->color
            );
            return newCar;
        }
	void showCar()
	{
			tyre->showTyre();
			engine->showEngine();
			cout<<"car color :: "<<int(color)<<endl;
	}
};

int main() {
    // creating a red tubeless petrol car
    Engine* engine = new Engine(ENGINE_TYPE::PETROL, 500, 4);
    Tyre* tyre = new Tyre(TYRE_THREAD_PATTERN::UNIDIRECTIONAL, TYRE_TYPE::TUBE_LESS, 30);
    Car* red_tubeless_petrol = new Car(tyre, engine, CAR_COLOR::RED);
	red_tubeless_petrol->showCar();
cout<<"********************************************"<<endl;
    	// creating a black tubeless petrol car
    Car* black_tubeless_petrol = red_tubeless_petrol->clone();
    black_tubeless_petrol->color = CAR_COLOR::BLACK;
	black_tubeless_petrol->showCar();

cout<<"********************************************"<<endl;
    // creating a red tubeType diesel car
    Car* red_tube_diesel = red_tubeless_petrol->clone();
    red_tube_diesel->tyre->type = TYRE_TYPE::TUBE_TYPE;
    red_tube_diesel->engine->type = ENGINE_TYPE::DIESEL;
	red_tube_diesel->showCar();

    return 0;
}
