#include <iostream>
#include <string>
#include<vector>
using namespace std;
class Vehicle
{
public:
    Vehicle(){
        parts.push_back("Engine");
        parts.push_back("FuelTanks");
    }
    string name;
    vector<string> parts;
    virtual Vehicle* clone() const = 0;
    virtual void listAllParts() const = 0;
    virtual void setVehicleName(string name)
    { this->name = name; }
    virtual void addParts(string part) 
    { 
	    parts.push_back(part); 
    }

    virtual ~Vehicle() { cout << "Vehicle Class has been destroyed and memory released...\n\n";  }
};

class Aircraft : public Vehicle
{
public:
    Aircraft(){
        addParts("IFE");
        addParts("Passenger Seats");
    }
    Aircraft*   clone() const { return new Aircraft; }
    void listAllParts() const {
        cout << "Vehicle Type : Aircraft\n";
        cout << "Vehicle Name : " << name << endl;
        for(int i =0; i< parts.size(); i++){
            cout << "Part: " << parts[i] << endl;
        }
        cout << "------------------------------\n";
    }
};

class Car : public Vehicle
{
public:
    Car(){
        addParts("Mirrors");
        addParts("Shift Gear");
    }
    Vehicle* clone() const { return new Car; }
    void listAllParts() const {
        cout << "Vehicle Type : Car\n";
        cout << "Vehicle Name : " << name << endl;
        for(int i =0; i< parts.size(); i++){
            cout << "Part:" << parts[i]<< endl;
        }
        cout << "------------------------------\n";
    }
};



class PrototypeFactory {
public:
    ~PrototypeFactory(){ cout << "Prototype Factory Has been destroyed and memory released\n\n"; }

    Vehicle* vehicle_prototypes(int index){
        if(index == 0)
		return new Aircraft;
	else
		return new Car;
    };

    Vehicle* preparePrototype( int prototypeIndex ){
        return vehicle_prototypes(prototypeIndex)->clone();
    }

};

static int INDEX_AIRCRAFT = 0;
static int INDEX_CAR = 1;


int main() {
    Vehicle *vec;
    PrototypeFactory *pFactory = new PrototypeFactory();
    vec = pFactory->preparePrototype(INDEX_AIRCRAFT);

    vec->setVehicleName("Boeing... ");
    vec->addParts("MCAS");//Maneuvering Characteristics Augmentation System
    vec->addParts("EICAS");//Engine Indicating and Crew Alerting System
    vec->listAllParts();

    //Created another type of same component
    vec = pFactory->preparePrototype(INDEX_AIRCRAFT);
    vec->setVehicleName("Airbus... ");
    vec->addParts("ECAM");//Electronic Centralized Aircraft Monitor
    vec->listAllParts();

    //Created another type of same component
    vec = pFactory->preparePrototype(INDEX_CAR);
    vec->setVehicleName("MURAT124... ");
    vec->addParts("SALLOW DOG");
    vec->addParts("DISCO BALL");
    vec->addParts("SUBWOOFERS");
    vec->listAllParts();

    delete pFactory;
    delete vec;

    return 0;
}

