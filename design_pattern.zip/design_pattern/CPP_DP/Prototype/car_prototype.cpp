#include<iostream>
#include<string>
#include<unistd.h>
using namespace std;
enum class ENGINE_TYPE :int{
    PETROL = 0,
    DIESEL,
    CNG,
    ELECTRIC
};

class Engine{
    public:
       ENGINE_TYPE type;
       int horsePower;
       int numCylinders;
       
       Engine(ENGINE_TYPE type, int horsePower, int numCylinders):type(type), horsePower(horsePower), numCylinders(numCylinders)
	{
	cout<<"creating engine"<<endl;
		sleep(5);
	}
};

enum class TYRE_THREAD_PATTERN :int{
    UNIDIRECTIONAL,
    ASYMMETRICAL,
    CONVENCTIONAL
};

enum class TYRE_TYPE : int{
    TUBE_LESS,
    TUBE_TYPE
};

class Tyre{
    public:
        int diameter;
        TYRE_THREAD_PATTERN threadPattern;
        TYRE_TYPE type;
        
        Tyre(TYRE_THREAD_PATTERN threadPattern, TYRE_TYPE type, int diameter)
            :diameter(diameter), threadPattern(threadPattern), type(type)
            {
		cout<<"creating tyre"<<endl;
		sleep(5);
	    }
};



enum class CAR_COLOR :int{
    RED,
    BLACK,
    WHITE,
    BLUE
};

class Car{
    public:
        Tyre *tyre;
        Engine *engine;
        CAR_COLOR color;

        Car(Tyre *tyre, Engine *engine, CAR_COLOR color)
            :tyre(tyre), engine(engine), color(color)
            {}
};


int main() {
    // creating a red tubeless petrol car
    Engine* engine1 = new Engine(ENGINE_TYPE::PETROL, 500, 4);
    Tyre* tyre1 = new Tyre(TYRE_THREAD_PATTERN::UNIDIRECTIONAL, TYRE_TYPE::TUBE_LESS, 30);
    Car* red_tubeless_petrol = new Car(tyre1, engine1, CAR_COLOR::RED);

    // creating a black tubeless petrol car
    Engine* engine2 = new Engine(ENGINE_TYPE::PETROL, 500, 4);
    Tyre* tyre2 = new Tyre(TYRE_THREAD_PATTERN::UNIDIRECTIONAL, TYRE_TYPE::TUBE_LESS, 30);
    Car* black_tubeless_petrol = new Car(tyre2, engine2, CAR_COLOR::BLACK);

    // creating a red tubeType diesel car
    Engine* engine3 = new Engine(ENGINE_TYPE::DIESEL, 500, 4);
    Tyre* tyre3 = new Tyre(TYRE_THREAD_PATTERN::UNIDIRECTIONAL, TYRE_TYPE::TUBE_TYPE, 30);
    Car* red_tube_diesel = new Car(tyre3, engine3, CAR_COLOR::RED);
	
    return 0;
}
