#include <iostream>

// Abstract Product Interface
class Pizza {
public:
    virtual void bake() = 0;
    virtual void cut() = 0;
    virtual void box() = 0;
};

// Concrete New York Cheese Pizza
class USCheesePizza : public Pizza {
public:
    void bake() override
    {
        std::cout << "Baking US-style cheese pizza."
                  << std::endl;
    }

    void cut() override
    {
        std::cout << "Cutting US-style cheese pizza."
                  << std::endl;
    }

    void box() override
    {
        std::cout << "Boxing US-style cheese pizza."
                  << std::endl;
    }
};

// Concrete New York Pepperoni Pizza
class USPepperoniPizza : public Pizza {
public:
    void bake() override
    {
        std::cout
            << "Baking US-style pepperoni pizza."
            << std::endl;
    }

    void cut() override
    {
        std::cout<< "Cutting US-style pepperoni pizza."<< std::endl;
    }

    void box() override
    {
        std::cout
            << "Boxing US-style pepperoni pizza."
            << std::endl;
    }
};

// Concrete Chicago Cheese Pizza
class IndiaCheesePizza : public Pizza {
public:
    void bake() override
    {
        std::cout << "Baking India-style cheese pizza."
                  << std::endl;
    }

    void cut() override
    {
        std::cout << "Cutting India-style cheese pizza."
                  << std::endl;
    }

    void box() override
    {
        std::cout << "Boxing India-style cheese pizza."
                  << std::endl;
    }
};

// Concrete Chicago Pepperoni Pizza
class IndiaPepperoniPizza : public Pizza {
public:
    void bake() override
    {
        std::cout << "Baking India-style pepperoni pizza."
                  << std::endl;
    }

    void cut() override
    {
        std::cout
            << "Cutting India-style pepperoni pizza."
            << std::endl;
    }

    void box() override
    {
        std::cout << "Boxing India-style pepperoni pizza."
                  << std::endl;
    }
};

// Abstract Factory Interface
class PizzaFactory {
public:
    virtual Pizza* createCheesePizza() = 0;
    virtual Pizza* createPepperoniPizza() = 0;
};

// Concrete US Pizza Factory
class USPizzaFactory : public PizzaFactory {
public:
    Pizza* createCheesePizza() override
    {
        return new USCheesePizza();
    }

    Pizza* createPepperoniPizza() override
    {
        return new USPepperoniPizza();
    }
};

// Concrete Chicago Pizza Factory
class IndiaPizzaFactory : public PizzaFactory {
public:
    Pizza* createCheesePizza() override
    {
        return new IndiaCheesePizza();
    }

    Pizza* createPepperoniPizza() override
    {
        return new IndiaPepperoniPizza();
    }
};

int main()
{
    // Create a US Pizza Factory
    PizzaFactory* USFactory
        = new USPizzaFactory();
    Pizza* USCheesePizza
        = USFactory->createCheesePizza();
    Pizza* USPepperoniPizza
        = USFactory->createPepperoniPizza();

    // Create a Chicago Pizza Factory
    PizzaFactory* IndiaFactory
        = new IndiaPizzaFactory();
    Pizza* IndiaCheesePizza
        = IndiaFactory->createCheesePizza();
    Pizza* IndiaPepperoniPizza
        = IndiaFactory->createPepperoniPizza();

    // Order and prepare the pizzas
    USCheesePizza->bake();
    USCheesePizza->cut();
    USCheesePizza->box();

    USPepperoniPizza->bake();
    USPepperoniPizza->cut();
    USPepperoniPizza->box();

    IndiaCheesePizza->bake();
    IndiaCheesePizza->cut();
    IndiaCheesePizza->box();

    IndiaPepperoniPizza->bake();
    IndiaPepperoniPizza->cut();
    IndiaPepperoniPizza->box();

    // Clean up
    delete USFactory;
    delete USCheesePizza;
    delete USPepperoniPizza;
    delete IndiaFactory;
    delete IndiaCheesePizza;
    delete IndiaPepperoniPizza;

    return 0;
}
