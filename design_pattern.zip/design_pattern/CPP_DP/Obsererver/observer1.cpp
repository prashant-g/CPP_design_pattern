#include<iostream>
#include<vector>
#include<string>
#include<algorithm>
using namespace std;


// Observer Interface
class Observer {
	public:
	virtual void update(string weather)=0;
};

class PhoneDisplay : public Observer {
	string weather;

	void display() {
		cout<<"Phone Display: Weather updated - " << weather<<endl;
	}
	
	public :
		void update(string weather) {
		this->weather = weather;
		display();
	}

};

// ConcreteObserver Class
class TVDisplay : public Observer {
	string weather;
	void display() {
		cout<<"TV Display: Weather updated - " << weather<<endl;
	}
	public :
	void update(string weather) {
		this->weather = weather;
		display();
	}
};


// Subject Interface
class Subject {
	public:
	virtual void addObserver(Observer *)=0;
	virtual void removeObserver(Observer *)=0;
	virtual void notifyObservers()=0;
};
// ConcreteSubject Class
class WeatherStation : public Subject {
	vector<Observer *> observers;
	string weather;

	public:
       	void addObserver(Observer *o) {
		observers.push_back(o);
		cout<<"added observer "<<observers.size()<<endl;
	}

	void removeObserver(Observer *o) {
        	auto it=find(observers.begin(), observers.end(), o);
		if(it!=observers.end())
		{
			observers.erase(it);
			cout<<"observer successfully removed"<<endl;
		}
		else
			cout<<"observer trying to remove not found"<<endl;
	}

	void notifyObservers() {
		for (Observer *observer : observers) {
			observer->update(weather);
		}
	}

	void setWeather(string newWeather) {
		this->weather = newWeather;
		notifyObservers();
	}
};

int main() 
{
	WeatherStation *weatherStation = new WeatherStation;
	Observer *phoneDisplay1 = new PhoneDisplay;
	Observer *phoneDisplay2 = new PhoneDisplay;
	Observer *phoneDisplay3 = new PhoneDisplay;
	Observer *tvDisplay1 = new TVDisplay;
	Observer *tvDisplay2 = new TVDisplay;
	Observer *tvDisplay3 = new TVDisplay;
	weatherStation->addObserver(phoneDisplay1);
	weatherStation->addObserver(phoneDisplay2);
	weatherStation->addObserver(phoneDisplay3);
	weatherStation->addObserver(tvDisplay1);
	weatherStation->addObserver(tvDisplay2);
	weatherStation->addObserver(tvDisplay3);
	weatherStation->setWeather("Sunny");
	//weatherStation->notifyObservers();
	
	cout<<"======================================================="<<endl;

	weatherStation->removeObserver(tvDisplay1);
	weatherStation->removeObserver(tvDisplay2);
	weatherStation->setWeather("Cloudy");
}

