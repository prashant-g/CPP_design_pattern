#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;

int main()
{
	vector<int> iv;
	iv.push_back(11);
	iv.push_back(22);
	iv.push_back(33);
	iv.push_back(44);
	iv.push_back(55);
	iv.push_back(66);
	iv.push_back(77);
	iv.push_back(88);

	for(auto a: iv)
		cout<<a<<endl;

	iv.erase(find(iv.begin(),iv.end(),55));
	cout<<"after delete"<<endl;
	for(auto a: iv)
		cout<<a<<endl;
}
