#include <iostream>
#include<vector>
#include<algorithm>
#include<unistd.h>
using namespace std;

class Observer {
public:
    virtual void update(int , int , float )=0;
};


class AverageScoreDisplay :public Observer
{
    float runRate;
  int predictedScore;

public:
 void display()
    {
        cout<<"\nAverage Score Display:"<<endl;
	cout<< "Run Rate: " << runRate <<endl;
	cout<<"PredictedScore: " <<predictedScore<<endl;
    }
    void update(int runs, int wickets, float overs)
    {
        this->runRate =(float)runs/overs;
        this->predictedScore = (int)(this->runRate * 50);
        display();
    }


};

 class CurrentScoreDisplay :public Observer
	{
	    int runs, wickets;
	    float overs;

	    public:
	void display()
	    {
	       cout<<"Current Score Display:"<<endl;
	          cout<< "Runs: " << runs <<endl;
	          cout<< "Wickets:" << wickets <<endl;
	              cout<<"Overs: "<<overs <<endl;
	    }
	void update(int runs, int wickets,float overs)
	    {
	        this->runs = runs;
	        this->wickets = wickets;
	        this->overs = overs;
	        display();
	    }



};

class  Subject {
	public:

	virtual void registerObserver(Observer *)=0;
    	virtual void unregisterObserver(Observer *)=0;
    	virtual void notifyObservers()=0;
};

class CricketData : public Subject {
	int runs;
    int wickets;
    float overs;
    vector<Observer *> observerList;

public:
     void registerObserver(Observer *o) {
        observerList.push_back(o);
    }

     void unregisterObserver(Observer *o) {
        observerList.erase(find(observerList.begin(), observerList.end(), o));
    }

     void notifyObservers()
    {
        for (auto it = observerList.begin(); it!=observerList.end();it++)
        {
            (*it)->update(runs,wickets,overs);
        }

    }

     void updateRunsOversWickets(int r, int w, float o)
    {
        //get latest data
	this->runs=r;
	this->wickets=w;
	this->overs=o;
        notifyObservers();
    }

};


int main()
	    {
	        // create objects for testing
	        Observer *averageScoreDisplay = new AverageScoreDisplay;
	        Observer *currentScoreDisplay = new CurrentScoreDisplay;

	        // pass the displays to Cricket data
	        CricketData *cricketData = new CricketData();

	        // register display elements
	        cricketData->registerObserver(averageScoreDisplay);
	        cricketData->registerObserver(currentScoreDisplay);

	        // in real app you would have some logic to
	        // call this function when data changes
	        cricketData->updateRunsOversWickets(87,2,10);

		sleep(10);
	        cricketData->updateRunsOversWickets(98,2,11);
		sleep(10);
		cricketData->unregisterObserver(averageScoreDisplay);
	        cricketData->updateRunsOversWickets(100,3,12);
		sleep(10);
	        cricketData->updateRunsOversWickets(105,3,13);

	    }





