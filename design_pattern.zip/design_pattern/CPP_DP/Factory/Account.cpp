
 class Account {
	int AN;
	float Bal;
	string Name,Address,Type;
	
public:
 Account(int a, float b, String n, String adr,String type)
	cout<<"set account details of account class"<<endl;
	AN=a;
	Bal=b;
	Name=n;
	Address=adr;
	Type=type;
	
}
 void showAccountDetails()
{
	cout<<"show account details of account class"<<endl;
	cout<<"Name  = "<<Name<<endl;
	cout<<"Account Number  = "<<AN;
	cout<<"Balance  = "<<Bal;
	cout<<"Address  = "<<Address;
}
public void withdraw(<<endl
{
	cout<<"withdraw of account class"<<endl;
	cout<<"withdraw of account class"<<endl;
	cout<<"withdraw of account class"<<endl;
}
void deposit()
{
	cout<<"deposit of account class"<<endl;
	cout<<"deposit of account class"<<endl;
	cout<<"deposit of account class"<<endl;
}
void netBanking()
{
	cout<<"netBanking of account class"<<endl;
	cout<<"netBanking of account class"<<endl;
	cout<<"netBanking of account class"<<endl;
}
virtual void intrest()=0;
};
