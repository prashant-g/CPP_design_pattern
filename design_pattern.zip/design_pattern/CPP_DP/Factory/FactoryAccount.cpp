
class FactoryAccount {
static Account *a;

static Account createAccount(int choice)
{
	if (choice == 1)
	{
		a=new SavingsAccount() ;
		return a;
	}
	else if (choice == 2)
	{
		a = new currentAccount(1234, 90000, "RAHUL", "BANGLORE","CA");
		return a;
	}
	else if (choice == 3)
	{
		a = new corpAccount(1234, 90000, "RAHUL", "BANGLORE","CPA");
		return a;
	}
	else if (choice == 4)
	{
		a = new RDAccount(1234, 90000, "RAHUL", "BANGLORE","RD");
		return a;
	}
	else
	{
		cout<<"invalid"<<endl;
		rteurn nullptr;
	}
	}
}

