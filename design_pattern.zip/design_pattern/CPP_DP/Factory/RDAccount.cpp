
class RDAccount : public Account {
	RDAccount(int an,float bal,String n, String Adr,String t): Account	(an,bal,n,Adr,t)
	{

	
	}
	void intrest()
	{
		cout<<"intrest of RDAccount class"<<endl;
		cot<<"intrest of RDAccount class"<<endl;
		cout<<"intrest of RDAccount class"<<endl;
	}
}
