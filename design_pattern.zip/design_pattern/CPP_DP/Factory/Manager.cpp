class BM
{
list <Account *> accounts;
 void add_account(){
		
		while(true)
		{
			cout<<"1: Savings Account\n2: Current Account"<<endl;
			cout<<"3: Corporate Account\n4: RD Account"<<endl;
			int choice;
			cin>>choice;
			if(choice > 4)
			break;
			else
			{
			Account *acc= FactoryAccount::createAccount(choice);
			accounts.push_back(acc);
			}
			
		}

}

void del_account()
{


}
void search_account()
{

}


void BMMenu()
{
cout<<"1 : Add account\n2 : Delete Account "<<endl;
cin>>ch;
switch (ch){
case 1:
add_account;
break;
case  2 :
del_account;


}


}
