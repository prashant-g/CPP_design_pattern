
class currentAccount : public Account {
	currentAccount(int an,float bal,String n, String Adr,String t): Account(an,bal,n,Adr,t)

	{
		
	}
	void intrest()
	{
		cout<<"intrest of currentAccount class"<<endl;
		cout<<"intrest of currentAccount class"<<endl;
		cout<<"intrest of currentAccount class"<<endl;
	}
}
