#include<iostream>
#include<string>
#include<list>
#include<vector>
using namespace std;



 class Account {
	int AN;
	float Bal;
	string Name,Address,Type;
	
public:
 Account(int a, float b, string n, string adr,string type){
	cout<<"set account details of account class"<<endl;
	AN=a;
	Bal=b;
	Name=n;
	Address=adr;
	Type=type;	
}
 void showAccountDetails(){
	cout<<"show account details of account class"<<endl;
	cout<<"Name  = "<<Name<<endl;
	cout<<"Account Number  = "<<AN;
	cout<<"Balance  = "<<Bal;
	cout<<"Address  = "<<Address;
}
void withdraw(){
	cout<<"withdraw of account class"<<endl;
	cout<<"withdraw of account class"<<endl;
	cout<<"withdraw of account class"<<endl;
}
void deposit(){
	cout<<"deposit of account class"<<endl;
	cout<<"deposit of account class"<<endl;
	cout<<"deposit of account class"<<endl;
}
virtual void netBanking()=0;
virtual void intrest()=0;
};

class savingAccount : public Account {
	public:
	savingAccount(int an,float bal,string n, string Adr,string t): Account(an,bal,n,Adr,t)
	{
	cout<<"savings account created"<<endl;	
	
	}
	 void intrest() //overriding
	{
		cout<<"intrest of savingAccount class"<<endl;
		cout<<"intrest of savingAccount class"<<endl;
		cout<<"intrest of savingAccount class"<<endl;
	}
	 void netBanking() //overriding
	{
		cout<<"netBanking of savingAccount class"<<endl;
	}
};

class currentAccount : public Account {
	public:
	currentAccount(int an,float bal,string n, string Adr,string t): Account(an,bal,n,Adr,t){
		
	}
	void intrest()
	{
		cout<<"intrest of currentAccount class"<<endl;
		cout<<"intrest of currentAccount class"<<endl;
		cout<<"intrest of currentAccount class"<<endl;
	}
	
	 void netBanking() //overriding
	{
		cout<<"netBanking of currentAccount class"<<endl;
	}
};

class RDAccount : public Account {
	public:
	RDAccount(int an,float bal,string n, string Adr,string t): Account(an,bal,n,Adr,t){

	
	}
	void intrest()
	{
		cout<<"intrest of RDAccount class"<<endl;
		cout<<"intrest of RDAccount class"<<endl;
		cout<<"intrest of RDAccount class"<<endl;
	}
	 void netBanking() //overriding
	{
		cout<<"netBanking of RDAccount class"<<endl;
	}
};

class corpAccount : public Account {
	public:
	 corpAccount(int an,float bal,string n, string Adr,string t): Account(an,bal,n,Adr,t){
	
	}
	void intrest()
	{
		cout<<"intrest of corpAccount class"<<endl;
		cout<<"intrest of corpAccount class"<<endl;
		cout<<"intrest of corpAccount class"<<endl;
	}
	 void netBanking() //overriding
	{
		cout<<"netBanking of corpAccount class"<<endl;
	}
};


class FactoryAccountConcrete {
private:
public:
static Account * createAccount(int choice)
{
	int ph,OTP;
		while(true)
		{
		cout<<"Enter phone :: "<<endl;
		cin>>ph;
		cout<<"enter OTP :: ";
		cin>>OTP;
		if(OTP == 12345)
		{
			cout<<"Phone number varified"<<endl;
			break;
		}
		else
		{
			cout<<"Invalid OTP "<<endl;
		}
		}
	if (choice == 1)
	{
		return new savingAccount(1234,99000,"Sachin","Banglore","SA") ;
	}
	else if (choice == 2)
	{
		return new currentAccount(1234, 90000, "RAHUL", "BANGLORE","CA");

	}
	else if (choice == 3)
	{
		return new corpAccount(1234, 90000, "RAHUL", "BANGLORE","CPA");
	}
	else if (choice == 4)
	{
		return new RDAccount(1234, 90000, "RAHUL", "BANGLORE","RD");
	}
	else
	{
		cout<<"invalid"<<endl;
		return NULL;
	}
}
};


class BM
{
	private:
		list <Account *> accounts;
	public:
 void add_account(){
		while(true){
			cout<<"1: Savings Account\n2: Current Account"<<endl;
			cout<<"3: Corporate Account\n4: RD Account"<<endl;
			int choice;
			cin>>choice;
			if(choice > 4)
			break;
			else
			{
			Account *acc= FactoryAccountConcrete::createAccount(choice);
			acc->netBanking();
			acc->intrest();
			acc->withdraw();
			accounts.push_back(acc);
			}
			
		}

}

void del_account()
{
	cout<<"Account deleted"<<endl;

}
void search_account()
{
	cout<<"Account search"<<endl;

}
void BMMenu()
{
int ch;
cout<<"1 : Add account\n2 : Delete Account "<<endl;
cin>>ch;
switch (ch){
case 1:
add_account();
break;
case  2 :
del_account();
}
}
};



class Broker {
private:
	vector<Account *> accounts;
public:

	void add_account()
		{
		while(true)
		{
			cout<<"1: Savings Account\n2: Current Account"<<endl;
			cout<<"\n4: RD Account"<<endl;
			int choice;
			cin>>choice;
			//verifyPhone();
			//verifyUID();
			if(choice > 4 || choice == 3)
			break;
			else
			{
			Account *acc= FactoryAccountConcrete::createAccount(choice);
			accounts.push_back(acc);
			}
		}
		}	
	
	void search_account()
	{
		cout<<"search account"<<endl;
	}


	void BrokerMenu()
	{
	int ch;
	cout<<"1 : Add account\n2 :Search Account "<<endl;
	cin>>ch;
	switch (ch){
	case 1:
		add_account();
		break;
	case  2 :
		search_account();
		break;

	}
}
};


int main()
{


	Broker *b= new Broker();
	b->BrokerMenu();
}
