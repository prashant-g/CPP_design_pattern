#include<iostream>

using namespace std;

class B
{
	int z;
	const int num;
	public:
	B(int m): num(99),z(m) 
	{
		cout<<"B Constructor"<<endl;
	}
	~B()
	{
		cout<<"z = "<<z<<endl;
		cout<<"num = "<<num<<endl;
		cout<<"B destructor"<<endl;
	}
};



int main()
{
	B ob(100);
	cout<<"end of main"<<endl;
}
