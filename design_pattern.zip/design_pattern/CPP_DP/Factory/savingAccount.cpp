
class savingAccount : public Account {
	savingAccount(int an,float bal,String n, String Adr,String t): Account(an,bal,n,Adr,t)
	{
	
	
	}
	 void intrest() //overriding
	{
		cout<<"intrest of savingAccount class"<<endl;
		cout<<"intrest of savingAccount class"<<endl;
		cout<<"intrest of savingAccount class"<<endl;
	}
}
