
public class corpAccount : public Account {
	 corpAccount(int an,float bal,String n, String Adr,String t): Account(an,bal,n,Adr,t)
	{
	
	
	}
	public void intrest()
	{
		cout<<"intrest of corpAccount class"<<endl;
		cout<<"intrest of corpAccount class"<<endl;
		cout<<"intrest of corpAccount class"<<endl;
	}
}
