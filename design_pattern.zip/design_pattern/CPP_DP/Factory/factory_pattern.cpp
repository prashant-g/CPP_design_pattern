#include<iostream>
#include<string>
#include<list>
#include<vector>
using namespace std;

 class Account {
	int AN;
	float Bal;
	string Name,Address,Type;
	
public:
 Account(int a, float b, string n, string adr,string type){
	cout<<"set account details of account class"<<endl;
	AN=a;
	Bal=b;
	Name=n;
	Address=adr;
	Type=type;	
}
 void showAccountDetails(){
	cout<<"show account details of account class"<<endl;
	cout<<"Name  = "<<Name<<endl;
	cout<<"Account Number  = "<<AN;
	cout<<"Balance  = "<<Bal;
	cout<<"Address  = "<<Address;
}
void withdraw(){
	cout<<"withdraw of account class"<<endl;
	cout<<"withdraw of account class"<<endl;
	cout<<"withdraw of account class"<<endl;
}
void deposit(){
	cout<<"deposit of account class"<<endl;
	cout<<"deposit of account class"<<endl;
	cout<<"deposit of account class"<<endl;
}
virtual void intrest()=0;
};

class savingAccount : public Account {
	public:
	savingAccount(int an,float bal,string n, string Adr,string t): Account(an,bal,n,Adr,t)
	{
	
	
	}
	 void intrest() //overriding
	{
		cout<<"intrest of savingAccount class"<<endl;
		cout<<"intrest of savingAccount class"<<endl;
		cout<<"intrest of savingAccount class"<<endl;
	}
	void netBanking()
	{
		cout<<"netBanking of saving account class"<<endl;
		cout<<"netBanking of saving account class"<<endl;
		cout<<"netBanking of savimg account class"<<endl;
	}
};

class currentAccount : public Account {
	public:
	currentAccount(int an,float bal,string n, string Adr,string t): Account(an,bal,n,Adr,t){
		
	}
	void intrest()
	{
		cout<<"intrest of currentAccount class"<<endl;
		cout<<"intrest of currentAccount class"<<endl;
		cout<<"intrest of currentAccount class"<<endl;
	}
	void netBanking()
	{
		cout<<"netBanking of saving current class"<<endl;
		cout<<"netBanking of saving current class"<<endl;
		cout<<"netBanking of savimg current class"<<endl;
	}
};

class RDAccount : public Account {
	public:
	RDAccount(int an,float bal,string n, string Adr,string t): Account(an,bal,n,Adr,t){

	
	}
	void intrest()
	{
		cout<<"intrest of RDAccount class"<<endl;
		cout<<"intrest of RDAccount class"<<endl;
		cout<<"intrest of RDAccount class"<<endl;
	}
	void netBanking()
	{
		cout<<"netBanking of RD account class"<<endl;
		cout<<"netBanking of RD account class"<<endl;
		cout<<"netBanking of RD account class"<<endl;
	}
};

class corpAccount : public Account {
	public:
	 corpAccount(int an,float bal,string n, string Adr,string t): Account(an,bal,n,Adr,t){
	
	}
	void intrest()
	{
		cout<<"intrest of corpAccount class"<<endl;
		cout<<"intrest of corpAccount class"<<endl;
		cout<<"intrest of corpAccount class"<<endl;
	}
	void netBanking()
	{
		cout<<"netBanking of corp account class"<<endl;
		cout<<"netBanking of corp account class"<<endl;
		cout<<"netBanking of corp account class"<<endl;
	}
};


class FactoryAccountConcrete {
private:
static Account *a;
public:
static Account * createAccount(int choice)
{
	if (choice == 1)
	{
		a=new savingAccount(1234,99000,"Sachin","Banglore","SA") ;
		return a;
	}
	else if (choice == 2)
	{
		a = new currentAccount(1234, 90000, "RAHUL", "BANGLORE","CA");
		return a;
	}
	else if (choice == 3)
	{
		a = new corpAccount(1234, 90000, "RAHUL", "BANGLORE","CPA");
		return a;
	}
	else if (choice == 4)
	{
		a = new RDAccount(1234, 90000, "RAHUL", "BANGLORE","RD");
		return a;
	}
	else
	{
		cout<<"invalid"<<endl;
		return NULL;
	}
}
};


Account * FactoryAccountConcrete::a=NULL;

class BM
{
	private:
		list <Account *> accounts;
	public:
 void add_account(){
		while(true){
			cout<<"1: Savings Account\n2: Current Account"<<endl;
			cout<<"3: Corporate Account\n4: RD Account"<<endl;
			int choice;
			cin>>choice;
			if(choice > 4)
			break;
			else
			{
			Account *acc= FactoryAccountConcrete::createAccount(choice);
			accounts.push_back(acc);
			}
			
		}

}

void del_account()
{
	cout<<"Account deleted"<<endl;

}
void search_account()
{
	cout<<"Account search"<<endl;

}
void BMMenu()
{
int ch;
cout<<"1 : Add account\n2 : Delete Account "<<endl;
cin>>ch;
switch (ch){
case 1:
add_account();
break;
case  2 :
del_account();
}
}
};



class Broker {
private:
	vector<Account *> accounts;
public:

	void add_account()
		{
		while(true)
		{
			cout<<"1: Savings Account\n2: Current Account"<<endl;
			cout<<"\n4: RD Account"<<endl;
			int choice;
			cin>>choice;
			if(choice > 4 || choice == 3)
			break;
			else
			{
			Account *acc= FactoryAccountConcrete::createAccount(choice);
			accounts.push_back(acc);
			}
		}
		}	
	
	void search_account()
	{
		cout<<"search account"<<endl;
	}


	void BrokerMenu()
	{
	int ch;
	cout<<"1 : Add account\n2 :Search Account "<<endl;
	cin>>ch;
	switch (ch){
	case 1:
		add_account();
		break;
	case  2 :
		search_account();
		break;

	}
}
};


int main()
{
	BM *bm=new BM;
	bm->BMMenu();
}
