
	class Broker
			{
			vector<Account *> accounts;
		void add_account()
		{
		while(true)
		{
			cout<<"1: Savings Account\n2: Current Account"<<endl;
			cout<<"\n4: RD Account"<<endl;
			int choice;
			cin>>choice;
			if(choice > 4 || choice == 3)
			break;
			else
			{
			Account *acc= FactoryAccount::createAccount(choice);
			accounts.push_back(acc)
			}
		}	
	
void search_account()
{

}


void BrokerMenu()
{
cout<<"1 : Add account\n2 :Search Account "<<endl;
cin>>ch;
switch (ch){
case 1:
add_account;
break;
case  2 :
search_account;
break;

}
}
