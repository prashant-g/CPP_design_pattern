#include<iostream>
#include<string>
using namespace std;

int main()
{
	string temp;
	cout<<"enter a string :: ";
	cin>>temp;
	cout<<"temp :: "<<temp<<endl;
}
