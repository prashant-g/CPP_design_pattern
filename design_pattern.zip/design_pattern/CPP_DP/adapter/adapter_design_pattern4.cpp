#include<iostream>
#include<string>
using namespace std;

class AbstractSwitchBoard {
public:
  void virtual FlatPin()=0;
  void virtual PinCount()=0;
};

// Adaptee
class SwitchBoard : public AbstractSwitchBoard {
public:
  void FlatPin() {
        cout << " Flat Pin" << endl;
  }
  void PinCount() {
        cout << " I have three pins" << endl;
  }
};

class AbstractPlug {
public:
  void virtual RoundPin()=0;
  void virtual PinCount()=0;
};
// Target

class Plug : public AbstractPlug {
public:
  void RoundPin() {
    cout << " I am Round Pin" << endl;
  }
  void PinCount() {
    cout << " I have two pins" << endl;
  }
};

// Adapter
class Adapter : public AbstractPlug {
public:
  AbstractSwitchBoard *board;
  Adapter(AbstractSwitchBoard *b) {
        board = b;
  }
  void RoundPin() {
        board->FlatPin();
  }
  void PinCount() {
        board->PinCount();
  }
};

// Client code
int main()
{
  SwitchBoard *mySwitchBoard = new SwitchBoard; // Adaptee
  AbstractPlug *adapter = new Adapter(mySwitchBoard);
  adapter->RoundPin();
  adapter->PinCount();
}
