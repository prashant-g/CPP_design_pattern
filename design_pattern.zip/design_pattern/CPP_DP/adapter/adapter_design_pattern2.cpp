#include <iostream>
#include <string>
#include <sstream>
using namespace std;

class AbstractEmp
{
		
public:
	virtual void setName(string n)=0;
	virtual string getName()=0;
};



class Emp: public AbstractEmp
{
	string name;
	public :
		void setName(string n)
		{
			name = n;
		}
		string getName()
		{
			return name;
		}
};

class AbstractAccount
{
public :
	virtual void setFirstName(string f)=0;
	virtual void setMiddleName(string f)=0;
	virtual void setLastName(string l)=0;
	virtual string getFirstName()=0;
	virtual string getLastName()=0;
};

class Account: public AbstractAccount
{
private  :
string firstName, middleName,lastName;
public :
	void setFirstName(string f)
	{
		firstName = f;
	}
	void setMiddleName(string f)
	{
		middleName = f;
	}
	void setLastName(string l)
	{
		lastName = l;
	}
	string getFirstName()
	{
		return firstName;
	}
	string getLastName()
	{
		return lastName;
	}
	string getMiddleName()
	{
		return middleName;
	}
};


class AdapterEmpAccount 
{

public :
	AdapterEmpAccount(AbstractEmp *a,AbstractAccount *b)//emp1
	{
	string sub;
	istringstream iss(a->getName());//Brian charles Karnighan
	iss >>sub;
	b->setFirstName(sub);
	iss >>sub;
	b->setMiddleName(sub);
	iss>>sub;
	b->setLastName(sub);
	}

};

int main()
{
Emp emp1;
emp1.setName("Brian charles kernighan");
Emp emp2;
emp2.setName("Rahul Sharad Dravid");
Account acc1;
Account acc2;
cout<<emp1.getName()<<endl;

AdapterEmpAccount adapter(&emp1,&acc1);
AdapterEmpAccount adapter1(&emp2,&acc2);
cout<<"Customer's first name: " << acc1.getFirstName()<<endl;
cout <<"Customer's middle name: " << acc1.getMiddleName()<<endl;
cout<<"Customer's last name: " << acc1.getLastName()<<endl;
cout<<"Customer's first name: " << acc2.getFirstName()<<endl;
cout <<"Customer's middle name: " << acc2.getMiddleName()<<endl;
cout<<"Customer's last name: " << acc2.getLastName()<<endl;
//adapter.setFirstName("bjarne");
//adapter.setLastName("stroustrup");
//cout<<"Customer's first name: " << adapter.getFirstName()<<endl;
//cout <<"Customer's last name: " << adapter.getLastName()<<endl;
return 0;
}
