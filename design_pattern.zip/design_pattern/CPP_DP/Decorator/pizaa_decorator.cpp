#include<iostream>
#include<string>
using namespace std;


class Pizza 
{ 
	protected :
	string description;
       

	public :
	Pizza()
	{
//		description= "Unkknown Pizza"; 
	}
	virtual string getDescription() 
	{ 
		return description; 
	} 

	 virtual int getCost()=0; 
} ;


// Concrete pizza classes 
class PeppyPaneer : public Pizza 
{ 
	public:
		PeppyPaneer() 
		{ 
			description = "PeppyPaneer"; 
		} 
		virtual int getCost() 
		{ 
			return 100; 
		} 
};

class FarmHouse :public  Pizza 
{ 
	public :
		FarmHouse() 
		{ 
			description = "FarmHouse"; 
		} 
		int getCost()
 		{ 
			return 200; 
		} 
};

class Margherita : public Pizza 
{ 
	public :
		Margherita() 
		{ 
			description = "Margherita"; 
		} 
		int getCost() 
		{ 
			return 100; 
		} 
};
class ChickenFiesta : public  Pizza 
{ 
	public :
		ChickenFiesta() 
		{ 
			description = "ChickenFiesta";
		} 
	int getCost() 
	{ 
		return 200; 
	} 
};
class SimplePizza : public Pizza 
{ 
	public:
		SimplePizza() 
		{ 
			description = "SimplePizza"; 
		} 
		int getCost() 
		{ 
			return 50; 
		} 
}; 

class ToppingsDecorator : public Pizza  
{ 
	public:
		virtual string getDescription()=0; 
};

// Concrete toppings classes 
class FreshTomato : public ToppingsDecorator 
{ 
	// we need a reference to obj we are decorating 
	Pizza *pizza; 

	public :
		FreshTomato(Pizza *pizza) 
		{ 
			this->pizza = pizza; 
		} 
		string getDescription() 
		{ 
			return pizza->getDescription() + ", Fresh Tomato "; 
		} 
		
		int getCost() 
		{ 
			return (40 + pizza->getCost()); 
		} 
};

class ExtraCheese : public ToppingsDecorator 
{ 
	Pizza *pizza; 
	public :
		ExtraCheese(Pizza *pizza) 
		{ 
			this->pizza = pizza; 
		} 
		string getDescription() 
		{ 
			return pizza->getDescription() + ", Extra cheese "; 
		} 
		int getCost() 
		{ 
			return 90 + pizza->getCost(); 
		} 
};
class Paneer : public ToppingsDecorator 
{ 
		Pizza *pizza; 
	public :
		Paneer(Pizza *pizza) 
		{
		       	this->pizza = pizza; 
		} 
		string getDescription() 
		{ 
			return pizza->getDescription() + ", Paneer "; 
		} 
		int getCost() 
		{ 
			return 70 + pizza->getCost(); 
		} 
};
int main() 
{ 
		// create new margherita pizza 
	Pizza *pizza1 = new Margherita();
        cout<<	pizza1->getDescription() << " Cost :" <<pizza1->getCost()<<endl; 
        Pizza *pizza2 = new FarmHouse(); 
        cout<<	pizza2->getDescription() << " Cost :" <<pizza2->getCost()<<endl; 
	pizza2 = new FreshTomato(pizza2); 
        cout<<	pizza2->getDescription() << " Cost :" <<pizza2->getCost()<<endl; 
	pizza2 = new ExtraCheese(pizza2); 
        cout<<	pizza2->getDescription() << " Cost :" <<pizza2->getCost()<<endl; 
} 
