#include<iostream>
#include<string>
#include<list>

using namespace std;


class LibraryItem
{
public:
  void SetNumCopies(int value)
  {
    numCopies_ = value;
  }
  int GetNumCopies(void)
  {
    return numCopies_;
  }
  virtual void Display(void)=0;
private:
  int numCopies_;
};


class Book : public LibraryItem
{
public:
  Book(string author, string title, int numCopies) : author_(author), title_(title)
  {
    SetNumCopies(numCopies);
  }
  void Display(void)
  {
    cout<<"\nBook ------ "<<endl;
    cout<<" Author : "<<author_<<endl;
    cout<<" Title : "<<title_<<endl;
    cout<<" # Copies : "<<GetNumCopies()<<endl;
  }
private:
  Book(); //Default not allowed
  string author_;
  string title_;
};

class Video : public LibraryItem
{
public:
  Video(string director, string title, int playTime, int numCopies) : director_(director), title_(title), playTime_(playTime)
  {
    SetNumCopies(numCopies);
  }
  void Display(void)
  {
    cout<<"\nVideo ------ "<<endl;
    cout<<" Director : "<<director_<<endl;
    cout<<" Title : "<<title_<<endl;
    cout<<" Play Time : "<<playTime_<<" mins"<<endl;
    cout<<" # Copies : "<<GetNumCopies()<<endl;
  }
private:
  Video(); //Default not allowed
  string director_;
  string title_;
  int playTime_;
};


class Magzine : public LibraryItem
{
  
public:
	Magzine(string type, string title, int pages, int numCopies) : type_(type), title_(title), pages_(pages)
  {
    SetNumCopies(numCopies);
  }
  void Display(void)
  {
    cout<<"\nMagzine ------ "<<endl;
    cout<<" Type : "<<type_<<endl;
    cout<<" Title : "<<title_<<endl;
    cout<<" pages : "<<pages_<<" mins"<<endl;
    cout<<" # Copies : "<<GetNumCopies()<<endl;
  }
private:
  string title_;
  string type_;
  int pages_;
};








class Decorator
{
public:
  Decorator(LibraryItem* libraryItem) 
{
       	this->libraryItem_=libraryItem;
 }
  void Display(void)
  {
    libraryItem_->Display();
  }
  int GetNumCopies(void)
  {
    return libraryItem_->GetNumCopies();
  }
virtual void DisplayDetails()=0;
protected:
  LibraryItem* libraryItem_;
private:
  Decorator(); //not allowed
};


class Borrowable : public Decorator
{
public:
  Borrowable(LibraryItem* libraryItem) : Decorator(libraryItem)
  {}
  void BorrowItem(string name)
  {
    borrowers_.push_back(name);
  }
  void DisplayDetails()
  {
    Display();
    int size = borrowers_.size();
    cout<<" # Available Copies : "<<(Decorator::GetNumCopies() - size)<<endl;
    auto it = borrowers_.begin();
    while(it != borrowers_.end())
    {
      cout<<" borrower: "<<*it<<endl;
      ++it;
    }
  }
protected:
  list<string> borrowers_;
};

class Sellable : public Decorator
{



};




int main()
{


Video video1("Peter Jackson", "The Lord of the Rings", 683, 24);
Video video2("spiel berg", "jurrassic", 544, 23);

video1.Display();
video2.Display();


Book book1("C++ Complete Refrence","Herbert schield",20);
Book book2("Disection of C++ ","Wrox publication",15);
book1.Display();
book2.Display();

Magzine mag1("Monthly","EFY",120,5);
mag1.Display();

  cout<<"Making video borrowable"<<endl;

  Borrowable borrowvideo(&video1);
  borrowvideo.BorrowItem("Bill Gates");
  borrowvideo.BorrowItem("Steve Jobs");
  borrowvideo.BorrowItem("jeff bezos");
  borrowvideo.BorrowItem("alan musk");
borrowvideo.DisplayDetails();
  
Borrowable borrowbook(&book2);
  borrowbook.BorrowItem("Mukesh Ambani");
  borrowbook.BorrowItem("Goutham Adani");
  borrowbook.BorrowItem("Radhakrishanan Damani");
  borrowbook.BorrowItem("Ratan Tata");
  borrowbook.BorrowItem("Bajaj");
borrowbook.DisplayDetails();


Borrowable bmag(&mag1);
  bmag.BorrowItem("Mukesh Ambani");
  bmag.BorrowItem("Goutham Adani");
  bmag.BorrowItem("Radhakrishanan Damani");
  bmag.BorrowItem("Ratan Tata");
  bmag.BorrowItem("Bajaj");
bmag.DisplayDetails();
 



return 0;
}


