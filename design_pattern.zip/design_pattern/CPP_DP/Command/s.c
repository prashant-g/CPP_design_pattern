#include<stdio.h>

int main()
{
	printf("hello ge\n");
	printf("this is the last design pattern for the day\n");
}
